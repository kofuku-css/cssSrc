﻿Imports GrapeCity.Win.Bars    '//追加(2017/06/13 18:02:44)
Imports GrapeCity.Win.Common
Imports GrapeCity.Win.Components
Imports Comsystem.Common
Imports Comsystem.Constants
Imports Comsystem.Forms
Imports Comsystem.Forms.Controls
Imports Comsystem.DataAccess
Imports GrapeCity.Win.Input.Interop
Imports FarPoint.Win.Spread


Public Class frmNKSRKM001
    Inherits Comsystem.Forms.Controls.BaseFormWithIMAndSpread

#Region " Windows フォーム デザイナで生成されたコード "

    Public Sub New()
        MyBase.New()

        ' この呼び出しは Windows フォーム デザイナで必要です。
        InitializeComponent()

        ' InitializeComponent() 呼び出しの後に初期化を追加します。
        '// フォームの初期化        
        FormSupport.InitializeForm(Me)
        MyBase.InitializeBaseFormWithIMAndSpread(Me)

    End Sub

    ' Form は、コンポーネント一覧に後処理を実行するために dispose をオーバーライドします。
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    ' メモ : 以下のプロシージャは、Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使って変更してください。  
    ' コード エディタを使って変更しないでください。
    Friend WithEvents ifkMain As GrapeCity.Win.Bars.GcClassicFunctionKey
    Friend WithEvents icntMain As GrapeCity.Win.Containers.GcContainer
    Friend WithEvents icntHead As GrapeCity.Win.Containers.GcContainer
    Friend WithEvents lblText As System.Windows.Forms.Label
    Friend WithEvents iedtKamokuCode As GrapeCity.Win.Input.Interop.Edit
	Friend WithEvents sprdMain As FarPoint.Win.Spread.FpSpread
	Friend WithEvents sprdMain_Sheet1 As FarPoint.Win.Spread.SheetView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim TextCellType1 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Dim TextCellType2 As FarPoint.Win.Spread.CellType.TextCellType = New FarPoint.Win.Spread.CellType.TextCellType()
        Me.ifkMain = New GrapeCity.Win.Bars.GcClassicFunctionKey()
        Me.icntMain = New GrapeCity.Win.Containers.GcContainer()
        Me.sprdMain = New FarPoint.Win.Spread.FpSpread()
        Me.sprdMain_Sheet1 = New FarPoint.Win.Spread.SheetView()
        Me.icntHead = New GrapeCity.Win.Containers.GcContainer()
        Me.iedtKamokuCode = New GrapeCity.Win.Input.Interop.Edit()
        Me.lblText = New System.Windows.Forms.Label()
        CType(Me.BaseStatusBarPanelMessage1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BaseStatusBarPanelMessage2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BaseStatusBarPanelProgress, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BaseStatusBarPanelDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BaseStatusBarPanelTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BaseProgressBar.SuspendLayout()
        Me.icntMain.SuspendLayout()
        CType(Me.sprdMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sprdMain_Sheet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.icntHead.SuspendLayout()
        CType(Me.iedtKamokuCode, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BaseStatusBar
        '
        Me.BaseStatusBar.Location = New System.Drawing.Point(0, 587)
        Me.BaseStatusBar.Size = New System.Drawing.Size(792, 24)
        '
        'BaseStatusBarPanelMessage1
        '
        Me.BaseStatusBarPanelMessage1.Width = 385
        '
        'BaseProgressBar
        '
        Me.BaseProgressBar.Location = New System.Drawing.Point(488, 591)
        Me.BaseProgressBar.Size = New System.Drawing.Size(92, 17)
        '
        'BaseProgressLavel
        '
        Me.BaseProgressLavel.Size = New System.Drawing.Size(92, 17)
        '
        'ifkMain
        '
        'Begin the custom initializing.(To create this information is just for debugging, it will be deleted in release version)
        Me.ifkMain.KeySets.Remove("Default")
        Me.ifkMain.KeySets.Add("Default", New GrapeCity.Win.Bars.KeySet(New GrapeCity.Win.Bars.KeyItem() {New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 0, False, System.Drawing.Color.Empty, -1, "F1", "F1"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 1, False, System.Drawing.Color.Empty, -1, "F2", "F2"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 2, False, System.Drawing.Color.Empty, -1, "F3", "F3"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 3, False, System.Drawing.Color.Empty, -1, "F4", "F4"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 4, True, System.Drawing.Color.Empty, -1, "F5 実行", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 5, True, System.Drawing.Color.Empty, -1, "F6 転記", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 6, False, System.Drawing.Color.Empty, -1, "F7", "F7"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 7, True, System.Drawing.Color.Empty, -1, "F8 キャンセル", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 8, False, System.Drawing.Color.Empty, -1, "F9", "F9"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 9, True, System.Drawing.Color.Empty, -1, "F10 終了", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 10, False, System.Drawing.Color.Empty, -1, "F11", "F11"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 11, False, System.Drawing.Color.Empty, -1, "F12", "F12"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 12, False, System.Drawing.Color.Empty, -1, "Home", "Home"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 13, False, System.Drawing.Color.Empty, -1, "End", "End"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 14, False, System.Drawing.Color.Empty, -1, "Page Up", "Page Up"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 15, False, System.Drawing.Color.Empty, -1, "Page Down", "Page Down")}))
        Me.ifkMain.StyleSets.Add("XPThemeStyleSet1", New GrapeCity.Win.Bars.XPThemeStyleSet(GrapeCity.Win.Bars.AlignHorizontal.NotSet, GrapeCity.Win.Bars.AlignVertical.NotSet, System.Drawing.SystemColors.Control, New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte)), System.Drawing.SystemColors.ControlText, GrapeCity.Win.Bars.ImagePosition.Left, 2, New GrapeCity.Win.Common.Margins(1, 1, 1, 1), GrapeCity.Win.Common.TextEffect.Flat, False, New GrapeCity.Win.Common.Bevel(System.Drawing.SystemColors.Control, 0, 25, -25), System.Windows.Forms.BorderStyle.Fixed3D))
        'End the custom initializing.(To create this information is just for debugging, it will be deleted in release version)
        Me.ifkMain.ActiveKeySet = "Default"
        Me.ifkMain.ActiveStyleSet = "XPThemeStyleSet1"
        Me.ifkMain.ColumnGroups = "4|4|2"
        Me.ifkMain.Location = New System.Drawing.Point(0, 553)
        Me.ifkMain.Name = "ifkMain"
        Me.ifkMain.Size = New System.Drawing.Size(792, 34)
        Me.ifkMain.TabIndex = 9
        '
        'icntMain
        '
        Me.icntMain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.icntMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.icntMain.Controls.Add(Me.sprdMain)
        Me.icntMain.Location = New System.Drawing.Point(240, 74)
        Me.icntMain.Name = "icntMain"
        Me.icntMain.Size = New System.Drawing.Size(368, 470)
        Me.icntMain.TabIndex = 12
        '
        'sprdMain
        '
        Me.sprdMain.AccessibleDescription = ""
        Me.sprdMain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.sprdMain.HorizontalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded
        Me.sprdMain.Location = New System.Drawing.Point(0, 0)
        Me.sprdMain.Name = "sprdMain"
        Me.sprdMain.SelectionBlockOptions = FarPoint.Win.Spread.SelectionBlockOptions.Rows
        Me.sprdMain.Sheets.AddRange(New FarPoint.Win.Spread.SheetView() {Me.sprdMain_Sheet1})
        Me.sprdMain.Size = New System.Drawing.Size(364, 466)
        Me.sprdMain.TabIndex = 0
        Me.sprdMain.VerticalScrollBarPolicy = FarPoint.Win.Spread.ScrollBarPolicy.AsNeeded
        '
        'sprdMain_Sheet1
        '
        Me.sprdMain_Sheet1.Reset()
        sprdMain_Sheet1.SheetName = "Sheet1"
        'Formulas and custom names must be loaded with R1C1 reference style
        Me.sprdMain_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.R1C1
        sprdMain_Sheet1.ColumnCount = 2
        sprdMain_Sheet1.RowCount = 1
        Me.sprdMain_Sheet1.ActiveSkin = New FarPoint.Win.Spread.SheetSkin("CustomSkin2", System.Drawing.SystemColors.AppWorkspace, System.Drawing.Color.White, System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(140, Byte), Integer)), System.Drawing.Color.Silver, FarPoint.Win.Spread.GridLines.Both, System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(140, Byte), Integer)), System.Drawing.Color.Empty, System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer)), System.Drawing.Color.Empty, System.Drawing.Color.FromArgb(CType(CType(115, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(156, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer)), False, False, False, True, False, True, False, True, "HeaderDefault", "HeaderDefault", "HeaderDefault", "DataAreaDefault", "HeaderDefault")
        Me.sprdMain_Sheet1.Cells.Get(0, 0).CellType = TextCellType1
        Me.sprdMain_Sheet1.Cells.Get(0, 0).Value = "1234567890"
        Me.sprdMain_Sheet1.Cells.Get(0, 1).CellType = TextCellType2
        Me.sprdMain_Sheet1.Cells.Get(0, 1).Value = "１２３４５６７８９０１２３４５"
        Me.sprdMain_Sheet1.ColumnFooter.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.sprdMain_Sheet1.ColumnFooter.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red
        Me.sprdMain_Sheet1.ColumnFooter.DefaultStyle.Parent = "HeaderDefault"
        Me.sprdMain_Sheet1.ColumnFooter.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.[Auto]
        Me.sprdMain_Sheet1.ColumnFooterSheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red
        Me.sprdMain_Sheet1.ColumnFooterSheetCornerStyle.Parent = "HeaderDefault"
        Me.sprdMain_Sheet1.ColumnHeader.Cells.Get(0, 0).Value = "科目コード"
        Me.sprdMain_Sheet1.ColumnHeader.Cells.Get(0, 1).Value = "科目名"
        Me.sprdMain_Sheet1.ColumnHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.sprdMain_Sheet1.ColumnHeader.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.sprdMain_Sheet1.ColumnHeader.DefaultStyle.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold)
        Me.sprdMain_Sheet1.ColumnHeader.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.sprdMain_Sheet1.ColumnHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red
        Me.sprdMain_Sheet1.ColumnHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.sprdMain_Sheet1.ColumnHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.sprdMain_Sheet1.ColumnHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.sprdMain_Sheet1.Columns.Get(0).Font = New System.Drawing.Font("ＭＳ ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.sprdMain_Sheet1.Columns.Get(0).Label = "科目コード"
        Me.sprdMain_Sheet1.Columns.Get(0).Width = 80.0!
        Me.sprdMain_Sheet1.Columns.Get(1).Font = New System.Drawing.Font("ＭＳ ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.sprdMain_Sheet1.Columns.Get(1).Label = "科目名"
        Me.sprdMain_Sheet1.Columns.Get(1).Width = 220.0!
        Me.sprdMain_Sheet1.DefaultStyle.BackColor = System.Drawing.Color.White
        Me.sprdMain_Sheet1.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.sprdMain_Sheet1.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red
        Me.sprdMain_Sheet1.DefaultStyle.Parent = "DataAreaDefault"
        Me.sprdMain_Sheet1.OperationMode = FarPoint.Win.Spread.OperationMode.RowMode
        Me.sprdMain_Sheet1.RowHeader.Columns.Default.Resizable = False
        Me.sprdMain_Sheet1.RowHeader.Columns.Default.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.sprdMain_Sheet1.RowHeader.Columns.Get(0).Width = 40.0!
        Me.sprdMain_Sheet1.RowHeader.DefaultStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.sprdMain_Sheet1.RowHeader.DefaultStyle.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold)
        Me.sprdMain_Sheet1.RowHeader.DefaultStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.sprdMain_Sheet1.RowHeader.DefaultStyle.NoteIndicatorColor = System.Drawing.Color.Red
        Me.sprdMain_Sheet1.RowHeader.DefaultStyle.Parent = "HeaderDefault"
        Me.sprdMain_Sheet1.RowHeader.DefaultStyle.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.sprdMain_Sheet1.RowHeader.Rows.Default.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.sprdMain_Sheet1.SheetCornerStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(74, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.sprdMain_Sheet1.SheetCornerStyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.sprdMain_Sheet1.SheetCornerStyle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.sprdMain_Sheet1.SheetCornerStyle.NoteIndicatorColor = System.Drawing.Color.Red
        Me.sprdMain_Sheet1.SheetCornerStyle.Parent = "HeaderDefault"
        Me.sprdMain_Sheet1.SheetCornerStyle.VisualStyles = FarPoint.Win.VisualStyles.Off
        Me.sprdMain_Sheet1.ReferenceStyle = FarPoint.Win.Spread.Model.ReferenceStyle.A1
        '
        'icntHead
        '
        Me.icntHead.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.icntHead.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.icntHead.Controls.Add(Me.iedtKamokuCode)
        Me.icntHead.Controls.Add(Me.lblText)
        Me.icntHead.Location = New System.Drawing.Point(240, 9)
        Me.icntHead.Name = "icntHead"
        Me.icntHead.Size = New System.Drawing.Size(368, 56)
        Me.icntHead.TabIndex = 11
        '
        'iedtKamokuCode
        '
        Me.iedtKamokuCode.AllowSpace = GrapeCity.Win.Input.Interop.AllowSpace.None
        Me.iedtKamokuCode.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.iedtKamokuCode.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.iedtKamokuCode.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.icntHead.SetCaptionFormat(Me.iedtKamokuCode, New GrapeCity.Win.Containers.CaptionFormat(80, 0, System.Drawing.Color.Transparent, System.Drawing.SystemColors.ControlText, New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte)), GrapeCity.Win.Common.TextHAlign.Left, GrapeCity.Win.Common.TextVAlign.Middle, GrapeCity.Win.Common.TextEffect.Flat, GrapeCity.Win.Containers.CaptionOrientation.Left, GrapeCity.Win.Common.TextWrapMode.WordWrap))
        Me.icntHead.SetCaptionText(Me.iedtKamokuCode, "科目コード")
        Me.iedtKamokuCode.ControlEffect = GrapeCity.Win.Input.Interop.ControlEffect.ThemeSensitive
        Me.iedtKamokuCode.Font = New System.Drawing.Font("ＭＳ ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.iedtKamokuCode.HighlightText = True
        Me.iedtKamokuCode.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.iedtKamokuCode.LengthAsByte = True
        Me.iedtKamokuCode.Location = New System.Drawing.Point(120, 17)
        Me.iedtKamokuCode.MaxLength = 4
        Me.iedtKamokuCode.Name = "iedtKamokuCode"
        Me.iedtKamokuCode.Size = New System.Drawing.Size(60, 22)
        Me.iedtKamokuCode.TabIndex = 0
        Me.iedtKamokuCode.TextHAlign = GrapeCity.Win.Input.Interop.AlignHorizontal.Right
        Me.iedtKamokuCode.TextVAlign = GrapeCity.Win.Input.Interop.AlignVertical.Middle
        '
        'lblText
        '
        Me.lblText.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.lblText.Location = New System.Drawing.Point(188, 17)
        Me.lblText.Name = "lblText"
        Me.lblText.Size = New System.Drawing.Size(32, 22)
        Me.lblText.TabIndex = 8
        Me.lblText.Text = "より"
        Me.lblText.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmNKSRKM001
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(792, 611)
        Me.ConfirmOnExit = False
        Me.Controls.Add(Me.icntHead)
        Me.Controls.Add(Me.ifkMain)
        Me.Controls.Add(Me.icntMain)
        Me.ExitOnEscape = True
        Me.MinimumSize = New System.Drawing.Size(800, 650)
        Me.Name = "frmNKSRKM001"
        Me.Text = "科目マスタ検索"
        Me.Controls.SetChildIndex(Me.icntMain, 0)
        Me.Controls.SetChildIndex(Me.BaseStatusBar, 0)
        Me.Controls.SetChildIndex(Me.BaseProgressBar, 0)
        Me.Controls.SetChildIndex(Me.ifkMain, 0)
        Me.Controls.SetChildIndex(Me.icntHead, 0)
        CType(Me.BaseStatusBarPanelMessage1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BaseStatusBarPanelMessage2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BaseStatusBarPanelProgress, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BaseStatusBarPanelDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BaseStatusBarPanelTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BaseProgressBar.ResumeLayout(False)
        Me.icntMain.ResumeLayout(False)
        CType(Me.sprdMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sprdMain_Sheet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.icntHead.ResumeLayout(False)
        CType(Me.iedtKamokuCode, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Private Field "

    Friend m_isFormInit		As Boolean = False                      'フォーム初期化
    Friend m_dialogResult	As DialogResult = DialogResult.None		'ダイアログの戻り値
    Friend m_kamokuCode		As Integer                              '選択科目コード
    Friend m_kamokuName		As String                               '選択科目名
	Friend m_kmkCode		As String                               '指定科目コード

    Private m_odpex As ODPEx = New ODPEx
    Private m_dskamoku		As New DataSet							'検索結果格納用データセット

    ''' <summary>スプレッドカラム幅退避領域</summary>
    Private m_sngColumnWidth() As Single = Nothing

#End Region 'Private Field

#Region " Private Const "
    Private Const TABLE_NAME As String = "科目マスタ"
#End Region

#Region " Private Enum "
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' SELECT文により取得した列をあらわす列挙体です。
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Enum EsqlColumn
        科目コード = 0
        科目名 = 1
    End Enum

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Spread 列定数
    ''' </summary>
    ''' <remarks>
    ''' 検索結果一覧
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Enum EsprdMainColumn
        ''' <summary>科目コード</summary>
        KamokuCode
        ''' <summary>科目名</summary>
        KamokuName
    End Enum

#End Region 'Private Enum

#Region " Main "
    <STAThread()> _
    Protected Shared Sub Main()
#If DEBUG Then
        FormSupport.AddExceptionEventHandlerWithContinue()
#Else
            FormSupport.AddExceptionEventHandler()
#End If

        Dim f As frmNKSRKM001 = New frmNKSRKM001
        Application.Run(f)
    End Sub
#End Region

#Region " Private Event "

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 科目マスタ検索Loadイベント
    ''' </summary>
    ''' <param name="sender">
    ''' </param>
    ''' <param name="e">
    ''' </param>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub frmNKSRKM001_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            MyBase.ConfirmOnExit = False

            ' Hack Tag設定
            Call SetControlTag()

            '/* コネクションストリング */
            m_odpex.ConnectionString = NKCOMMON.NKIni.GetConnectionString

            ' Hack スプレッドカラム幅退避
            NKCOMMON.NKLibrary.SaveSpreadColumnWidth(Me.sprdMain_Sheet1, Me.m_sngColumnWidth)

            'コントロールの初期化
            If Not InitialControls() Then
                Call ApplicationEnd()
            End If

        Catch ex As Exception
            MessageBox.Show("Load:" & ex.ToString())
            Debug.WriteLine(ex.ToString)
        End Try
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 科目マスタ検索Activatedイベント
    ''' </summary>
    ''' <param name="sender">
    ''' </param>
    ''' <param name="e">
    ''' </param>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub frmNKSRKM001_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        Try
            '初期化処理済の場合は処理終了
            If m_isFormInit Then
                Exit Sub
            Else
                m_isFormInit = True
            End If

            Application.DoEvents()

            'アプリケーション初期化
            If Not ApplicationStart() Then
                Call ApplicationEnd()
            End If

            If Search(iedtKamokuCode.Text) Then
                sprdMain.Focus()
            Else
                iedtKamokuCode.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show("Activated:" & ex.ToString())
            Debug.WriteLine(ex.ToString)
        End Try
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' ファンクションキーFunctionKeyPressイベント
    ''' </summary>
    ''' <param name="sender">
    ''' </param>
    ''' <param name="e">
    ''' </param>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub ifkMain_FunctionKeyPress(ByVal sender As Object, ByVal e As GrapeCity.Win.Bars.FunctionKeyPressEventArgs) Handles ifkMain.FunctionKeyPress
        Try
            Select Case e.Key
                Case ButtonKeys.F5
                    '/* 実行 */
                    If Search(iedtKamokuCode.Text) Then
                        sprdMain.Focus()
                    Else
                        iedtKamokuCode.Focus()
                    End If

                    Cursor = Cursors.Default

                Case ButtonKeys.F6
                    '/* 取込 */
                    If Not sprdMain.ActiveSheet.GetText(sprdMain.ActiveSheet.ActiveRowIndex, EsprdMainColumn.KamokuCode) = String.Empty Then
                        GetSelectedInfo(sprdMain.ActiveSheet.ActiveRowIndex)
                        m_dialogResult = DialogResult.OK
                        Close()
                    End If

                Case ButtonKeys.F8
                    '/* 中止 */
                    If Not InitialControls() Then
                        m_dialogResult = DialogResult.Abort
                        Call ApplicationEnd()
                    End If

                Case ButtonKeys.F10
                    '/* 終了 */
                    m_dialogResult = DialogResult.Cancel
                    Close()

            End Select

            e.Handled = True
        Catch ex As Exception
            MessageBox.Show("FunctionKeyPress:" & ex.ToString())
            Debug.WriteLine(ex.ToString)
        End Try
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 科目コード KeyDownイベント
    ''' </summary>
    ''' <param name="sender">
    ''' </param>
    ''' <param name="e">
    ''' </param>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/08	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub iedtKamokuCode_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles iedtKamokuCode.KeyDown
        Try
            Select Case e.KeyCode
                Case Keys.Enter
                    iedtKamokuCode.Text = iedtKamokuCode.Text.PadLeft(4, CChar("0"))

                    If Search(iedtKamokuCode.Text) Then
                        sprdMain.Focus()
                    Else
                        iedtKamokuCode.Focus()
                    End If

            End Select

        Catch ex As Exception
            Throw
        End Try
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Spread CellClickイベント
    ''' </summary>
    ''' <param name="sender">
    ''' </param>
    ''' <param name="e">
    ''' </param>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/08	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub sprdMain_CellClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles sprdMain.CellClick
        If Not e.ColumnHeader AndAlso Not sprdMain.ActiveSheet.GetText(e.Row, EsprdMainColumn.KamokuCode) = String.Empty Then
            GetSelectedInfo(e.Row)
            m_dialogResult = DialogResult.OK
            Close()
        End If
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Spread CellDoubleClickイベント
    ''' </summary>
    ''' <param name="sender">
    ''' </param>
    ''' <param name="e">
    ''' </param>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub sprdMain_CellDoubleClick(ByVal sender As Object, ByVal e As FarPoint.Win.Spread.CellClickEventArgs) Handles sprdMain.CellDoubleClick
        If Not e.ColumnHeader AndAlso Not sprdMain.ActiveSheet.GetText(e.Row, EsprdMainColumn.KamokuCode) = String.Empty Then
            GetSelectedInfo(e.Row)
            m_dialogResult = DialogResult.OK
            MyBase.ConfirmOnExit = False
            Close()
        End If
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Spread KeyDownイベント
    ''' </summary>
    ''' <param name="sender">
    ''' </param>
    ''' <param name="e">
    ''' </param>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/08	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub sprdMain_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles sprdMain.KeyDown

        If e.KeyCode = Keys.Enter Then
            If Not sprdMain.ActiveSheet.GetText(sprdMain.ActiveSheet.ActiveRowIndex, EsprdMainColumn.KamokuCode) = String.Empty Then
                GetSelectedInfo(sprdMain.ActiveSheet.ActiveRowIndex)
                m_dialogResult = DialogResult.OK
                Close()
            Else
                e.Handled = True
                sprdMain.Focus()
            End If
        End If

    End Sub

#End Region ' Private Event

#Region " Private Method "

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' アプリケーション初期処理
    ''' </summary>
    ''' <returns>
    ''' </returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Function ApplicationStart() As Boolean
        Try
            Return True
        Catch ex As Exception
            MessageBox.Show("ApplicationStart:" & ex.ToString())
            Debug.WriteLine(ex.ToString)
        End Try
    End Function

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' アプリケーション終了処理
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub ApplicationEnd()
        Try
            Close()
        Catch ex As Exception
            MessageBox.Show("ApplicationEnd:" & ex.ToString())
            Debug.WriteLine(ex.ToString)
        End Try
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' ステータス表示
    ''' </summary>
    ''' <param name="strStatusText">
    ''' ステータスバー表示文字列
    ''' </param>
    ''' <param name="curStyle">
    ''' カーソルタイプ
    ''' </param>
    ''' <remarks>
    ''' ステータスバー表示文字列の変更と、カーソルの変更
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub setFormStatus(Optional ByVal strStatusText As String = "", _
    Optional ByVal curStyle As System.Windows.Forms.Cursor = Nothing _
      )
        If (Nothing Is curStyle) Then
            curStyle = Cursors.Default
        End If

        BaseStatusBar.Panels(0).Text = strStatusText
        Cursor.Current = curStyle
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' コントロールタグ設定
    ''' </summary>
    ''' <remarks>
    ''' 画面コントロールのタグを設定します。
    ''' ここで設定されたメッセージがステータスバーに表示されます。
    ''' </remarks>
    ''' <history>
    ''' 	[kfc_takahashi]	2006/06/04	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub SetControlTag()

        Me.iedtKamokuCode.Tag = "科目コード" & MessageEx.INFO_SUFFIX_INPUT

    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' コントロールの初期化を行います。
    ''' </summary>
    ''' <returns>
    ''' </returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Function InitialControls() As Boolean
        Try
            Cursor = Cursors.WaitCursor

            ' Hack 検索条件初期化
            Call InputManEx.ClearControlCollection(Me.icntHead)

            If Not m_kmkCode = String.Empty Then
                iedtKamokuCode.Text = m_kmkCode.PadLeft(4, CChar("0"))
            Else
                iedtKamokuCode.Text = "0000"
            End If

            'Spreadの初期化
            If Not InitialSpread() Then
                ApplicationEnd()
            End If

            ifkMain.KeySets(0).Item(5).Enabled = False 'F6  転記

            ' Hack フォーカス設定
            Me.iedtKamokuCode.Focus()

            Return True

        Catch ex As Exception
            MessageBox.Show("InitialControls:" & ex.ToString())
            Debug.WriteLine(ex.ToString)
        Finally
            Cursor = Cursors.Default
        End Try
    End Function

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' SPREADの初期化を行います。
    ''' </summary>
    ''' <returns>
    ''' </returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/09	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Function InitialSpread() As Boolean
        Dim sprd As SheetView = sprdMain.ActiveSheet
        Try

            ' スプレッド
            SpreadEx.InitializeViewSingleSelectSpread(Me.sprdMain, EInputMapMode.None, 0, 0, ESort.None)
            ' 科目コード
            SpreadEx.SetColumnReadText(Me.sprdMain, EsprdMainColumn.KamokuCode, Nothing, EHAlign.Center)
            ' 科目名
            SpreadEx.SetColumnReadText(Me.sprdMain, EsprdMainColumn.KamokuName, Nothing)

            'sprd.Tag = "一覧上で行を選択後、リターンキーまたは選択ボタンを押して下さい。"
            'sprd.RowCount = 0

            ''/* 科目コード */
            'sprd.Columns(EsprdMainColumn.KamokuCode).CellType = text
            'sprd.Columns(EsprdMainColumn.KamokuCode).HorizontalAlignment = CellHorizontalAlignment.Right
            'sprd.Columns(EsprdMainColumn.KamokuCode).VerticalAlignment = CellVerticalAlignment.Center
            ''sprd.Columns(EsprdMainColumn.KamokuCode).Resizable = False
            'sprd.Columns(EsprdMainColumn.KamokuCode).Locked = True

            ''/* 科目名 */
            'sprd.Columns(EsprdMainColumn.KamokuName).CellType = text
            'sprd.Columns(EsprdMainColumn.KamokuName).HorizontalAlignment = CellHorizontalAlignment.Left
            'sprd.Columns(EsprdMainColumn.KamokuName).VerticalAlignment = CellVerticalAlignment.Center
            ''sprd.Columns(EsprdMainColumn.KamokuName).Resizable = False
            'sprd.Columns(EsprdMainColumn.KamokuName).Locked = True

            '2019/02/26 ADD(ST)
            'セルの選択中はSelectionForeColorとSelectionBackColorを使用し、背景色・フォント色を設定します
            sprdMain.ActiveSheet.SelectionStyle = FarPoint.Win.Spread.SelectionStyles.SelectionColors
            sprdMain.ActiveSheet.SelectionBackColor = NKCOMMON.NKConst.SEARCH_SPREAD_SELECTION_BACK_COLOR
            sprdMain.ActiveSheet.SelectionForeColor = NKCOMMON.NKConst.SEARCH_SPREAD_SELECTION_FORE_COLOR
            '2019/02/26 ADD(END)

            ' Hack スプレッドカラム幅設定
            NKCOMMON.NKLibrary.SetSpreadColumnWidth(Me.sprdMain_Sheet1, Me.m_sngColumnWidth)

            sprdMain.Enabled = False

            Return True

        Catch ex As Exception
            MessageBox.Show("InitialSpread:" & ex.ToString())
        End Try
    End Function

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 一覧上で選択されている情報を退避する。
    ''' </summary>
    ''' <param name="row">
    ''' </param>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub GetSelectedInfo(ByVal row As Integer)

        m_kamokuCode = CInt(sprdMain.ActiveSheet.GetValue(row, EsprdMainColumn.KamokuCode))
        m_kamokuName = sprdMain.ActiveSheet.GetText(row, EsprdMainColumn.KamokuName)

    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 指定された条件でデータベースを検索します。
    ''' </summary>
    ''' <returns>
    ''' </returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Function Search(ByVal strCode As String) As Boolean
        Try
            setFormStatus("検索中です...", Cursors.WaitCursor)

            sprdMain.ActiveSheet.Rows.Count = 0

            If GetData(strCode) = True Then
                SetDataInSpread()
                ifkMain.KeySets(0).Item(5).Enabled = True  'F6 取込 使用可
                Return True
            Else
                sprdMain.Enabled = False
                ifkMain.KeySets(0).Item(5).Enabled = False  'F6 取込 使用不可
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("Serch:" & ex.ToString())
            Debug.WriteLine(ex.ToString)
        Finally
            setFormStatus(String.Empty, Cursors.Default)
        End Try
    End Function

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 取得した情報をSpreadに表示する
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub SetDataInSpread()
        Dim dr As DataRow
        Dim row As Integer = 0

        Try
            '初期処理
            sprdMain.ActiveSheet.Rows.Count = m_dskamoku.Tables(TABLE_NAME).Rows.Count
            BaseProgressBar.Value = 0
            BaseProgressBar.Visible = True

            '取得データをSpreadへ表示
            For Each dr In m_dskamoku.Tables(TABLE_NAME).Rows
                BaseProgressBar.PerformStep()

                sprdMain.ActiveSheet.SetValue(row, EsprdMainColumn.KamokuCode, CStr(dr(EsqlColumn.科目コード)).PadLeft(4, CChar("0")))
                sprdMain.ActiveSheet.SetValue(row, EsprdMainColumn.KamokuName, dr(EsqlColumn.科目名))

                row += 1
            Next

            sprdMain.Enabled = True
            '2019/02/26 EDIT(ST)
            '先頭行を選択状態にする
            'sprdMain.ActiveSheet.SetActiveCell(0, 0, True)
            'sprdMain.ActiveSheet.ActiveRowIndex = 0
            sprdMain.ActiveSheet.AddSelection(sprdMain.ActiveSheet.ActiveRowIndex, -1, 1, -1)
            '2019/02/26 EDIT(END)

            ifkMain.KeySets(0).Item(5).Enabled = True  'F6 取込 使用可

        Catch ex As Exception
            MessageBox.Show("SetKokyakuDataInSpread:" & ex.ToString())
            Debug.WriteLine(ex.ToString)
        Finally
            Me.BaseProgressBar.Visible = False
        End Try
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 検索条件にマッチする情報を取得する
    ''' </summary>
    ''' <returns>
    ''' </returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/06	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Function GetData(ByVal strCode As String) As Boolean
        Dim sql As New System.Text.StringBuilder
        Dim sqlString As String

        Try
            sql = New System.Text.StringBuilder
            sql.Append("SELECT")
            sql.Append("       /*+ FIRST_ROWS */")
            sql.Append("       ""ZMJCD""     ""科目コード""")
            sql.Append("     , ""ZMJNM""     ""科目名""")
            sql.Append("  FROM")
            sql.Append("       ""科目マスタ""")
            sql.Append(" WHERE")
            sql.Append("       ""ZMJCD"" >= " & CInt(strCode))

            sqlString = sql.ToString
            m_dskamoku = New DataSet

            m_odpex.Fill(m_dskamoku, TABLE_NAME, sqlString)

            If (Not (m_dskamoku.Tables(TABLE_NAME).Rows.Count > 0)) Then
                Return False
            Else
                Return True
            End If

        Catch ex As Exception
            MessageBox.Show("GetData:" & ex.ToString())
            Debug.WriteLine(ex.ToString)
        Finally
            sql = Nothing
        End Try
    End Function

#End Region     ' Private Method

End Class
