﻿Imports GrapeCity.Win.Bars    '//追加(2017/06/13 18:02:44)
''' -----------------------------------------------------------------------------
''' Project	 : NKSRKM001
''' Class	 : KamokuSearch
''' 
''' Copyright (C) 2006, ComSystem Corporation
''' 
''' -----------------------------------------------------------------------------
''' <summary>
''' 科目マスタ検索ダイアログを表示して科目マスタ検索を行うクラスです。
''' </summary>
''' <remarks>
''' 条件指定を行い、科目マスタの検索を行います。
''' 検索後に選択された情報として次の情報を取得することができます。
''' <list type="bullet">
'''     <item>
'''			<term>科目コード</term>
'''     </item>
'''     <item>
'''			<term>科目名</term>
'''     </item>
''' </list>
''' <para> </para>
''' <example>
''' </example>
''' <para> </para>
''' </remarks>
''' <history>
''' 	[mori]		2006/06/06	Created
''' </history>
''' -----------------------------------------------------------------------------
Public Class KamokuSearch

    Private _myNKSRKM001 As frmNKSRKM001       '科目マスタ検索

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/05	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Sub New()
        _myNKSRKM001 = New frmNKSRKM001
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 科目マスタ検索で使用しているリソースを全て開放します。
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/05	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Sub Dispose()
        Try
            If Not _myNKSRKM001 Is Nothing Then
                _myNKSRKM001.Close()
                _myNKSRKM001.Dispose()
                _myNKSRKM001 = Nothing
            End If
        Catch ex As Exception
            MessageBox.Show("Dispose:" & ex.ToString())
        End Try
    End Sub

#Region " Public Method "

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 指定した所有者を持つモーダル ダイアログとして科目マスタ検索を表示します。
    ''' </summary>
    ''' <param name="owner">
    ''' モーダル ダイアログを所有するトップレベル ウィンドウを表す System.Windows.Forms.IWin32Window を
    ''' 実装しているオブジェクト。
    ''' </param>
    ''' <returns>
    '''  System.Windows.Forms.DialogResult 値の 1 つ。  
    ''' </returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/05	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Function ShowDialog(ByVal owner As System.Windows.Forms.IWin32Window) As DialogResult
        Try
            _myNKSRKM001.ShowDialog(owner)
            Return DialogResult
        Catch ex As Exception
            MessageBox.Show("ShowDialog:" & ex.ToString())
        End Try
    End Function

    Public Function ShowDialog() As DialogResult
        _myNKSRKM001.ShowDialog()
        Return DialogResult
    End Function

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 科目マスタ検索をユーザーに対して表示します。
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/05	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Sub Show()
        _myNKSRKM001.Show()
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' このクラスで取得可能なプロパティ情報を全て取得します。
    ''' </summary>
    ''' <returns>
    ''' </returns>
    ''' <remarks>
    ''' 主にデバッグ用として使用するために実装されています。
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/05	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public ReadOnly Property ItemArray() As Object()
        Get
            Dim myObject(2) As Object
            myObject(0) = DialogResult
            myObject(1) = SelectedKamokuCode
            myObject(2) = SelectedKamokuName

            Return myObject
        End Get
    End Property

#End Region 'Public Method

#Region " Public Property "
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' データ抽出条件で科目コードを設定します
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/08	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
	Public Property KmkCode() As String
		Get
			Return _myNKSRKM001.m_kmkCode
		End Get
		Set(ByVal Value As String)
			_myNKSRKM001.m_kmkCode = Value
		End Set
	End Property

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' ダイアログの戻り値を取得します。
    ''' </summary>
    ''' <returns>
    ''' </returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/05	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public ReadOnly Property DialogResult() As DialogResult
        Get
            Return _myNKSRKM001.m_dialogResult
        End Get
    End Property

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 選択された科目コードを取得します。
    ''' </summary>
    ''' <returns>
    ''' </returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/05	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public ReadOnly Property SelectedKamokuCode() As Integer
        Get
            Return _myNKSRKM001.m_kamokuCode
        End Get
    End Property

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 選択された科目名を取得します。
    ''' </summary>
    ''' <returns>
    ''' </returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[mori]		2006/06/05	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public ReadOnly Property SelectedKamokuName() As String
        Get
            Return _myNKSRKM001.m_kamokuName
        End Get
    End Property

#End Region 'Public Property

End Class
