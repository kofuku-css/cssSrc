﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' アセンブリに関する一般情報は以下の
' 属性セットを通して制御されます。アセンブリに関連付けられている情報を変更するには、
' これらの属性値を変更してください。 

' アセンブリ属性の値を確認します。

<Assembly: AssemblyTitle("NKSRKM001.dll")> 
<Assembly: AssemblyDescription("科目マスタ検索")> 
<Assembly: AssemblyCompany("Comsystem")> 
<Assembly: AssemblyProduct("販売管理システム")> 
<Assembly: AssemblyCopyright("Copyright(C) 2006 ComSystem Co.,Ltd. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(False)>

'以下の GUID は、このプロジェクトが COM に公開された場合、タイプ ライブラリの ID になります。
<Assembly: Guid("267E50F0-B685-4D6A-9D2F-746D9C82DB7A")> 

' アセンブリのバージョン情報は、以下の 4 つの属性で構成されます :
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' 下にあるように、'*' を使って、すべての値を指定するか、
' ビルドおよびリビジョン番号を既定値にすることができます。

<Assembly: AssemblyVersion("1.0.*")> 
