﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("NKMTIN88_TEST")>
<Assembly: AssemblyDescription("銀行マスタ登録")>
<Assembly: AssemblyCompany("Comsystem")>
<Assembly: AssemblyProduct("販売管理システム")>
<Assembly: AssemblyCopyright("Copyright(C) 2009 ComSystem Co.,Ltd. All Rights Reserved.")>
<Assembly: AssemblyTrademark("")>
<Assembly: CLSCompliant(False)>

<Assembly: ComVisible(False)>

<Assembly: Guid("53efc500-1545-4918-8f93-6a4df17e45ea")>

' <Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
