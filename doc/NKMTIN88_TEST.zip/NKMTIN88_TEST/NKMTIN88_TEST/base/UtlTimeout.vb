﻿Imports System
Imports System.Windows.Forms

''' <summary>
''' タイムアウト処理に関するヘルパクラス
''' </summary>
Public Class UtlTimeout

#Region "列挙型"

    ''' <summary>待ち状況</summary>
    Public Enum WAIT_STATUS
        ''' <summary>成功</summary>
        SUCCESS

        ''' <summary>失敗</summary>
        [ERROR]

        ''' <summary>処理継続</summary>
        [CONTINUE]
    End Enum

#End Region

#Region "実行待ち処理"

    ''' <summary>
    ''' 実行待ち処理
    ''' </summary>
    ''' <param name="pFunc">評価関数</param>
    ''' <param name="ptsTimeout">タイムアウト</param>
    ''' <param name="pintInterval">インターバル</param>
    ''' <returns></returns>
    Public Shared Function WaitForFunc(pFunc As Func(Of Boolean), ptsTimeout As TimeSpan, Optional pintInterval As Integer = 50) As Boolean
        'タイムアウトまでループ
        Dim sw As Stopwatch = Stopwatch.StartNew()
        While (sw.Elapsed < ptsTimeout)
            '処理実行
            Dim bRet As Boolean = pFunc()
            If bRet Then
                Return True
            End If

            'Application.DoEvents()は記述しない
            'スレッドをWindowsに返す
            Threading.Thread.Sleep(pintInterval)
        End While

        ' タイムアウト
        Return False
    End Function

    ''' <summary>
    ''' 実行待ち処理
    ''' </summary>
    ''' <param name="pFunc">評価関数</param>
    ''' <param name="ptsTimeout">タイムアウト</param>
    ''' <param name="pintInterval">インターバル</param>
    ''' <returns></returns>
    Public Shared Function WaitForFunc(pFunc As Func(Of Object), ptsTimeout As TimeSpan, Optional pintInterval As Integer = 50) As Object
        'タイムアウトまでループ
        Dim sw As Stopwatch = Stopwatch.StartNew()
        While (sw.Elapsed < ptsTimeout)
            '処理実行
            Dim obj As Object = pFunc()
            If obj IsNot Nothing Then
                Return obj
            End If

            'Application.DoEvents()は記述しない
            'スレッドをWindowsに返す
            Threading.Thread.Sleep(pintInterval)
        End While

        ' タイムアウト
        Return Nothing
    End Function

    ''' <summary>
    ''' 実行待ち処理
    ''' </summary>
    ''' <param name="pFunc">評価関数</param>
    ''' <param name="ptsTimeout">タイムアウト</param>
    ''' <param name="pintInterval">インターバル</param>
    ''' <returns></returns>
    Public Shared Function WaitForFunc(pFunc As Func(Of WAIT_STATUS), ptsTimeout As TimeSpan, Optional pintInterval As Integer = 50) As Boolean
        'タイムアウトまでループ
        Dim sw As Stopwatch = Stopwatch.StartNew()
        While (sw.Elapsed < ptsTimeout)
            '処理実行
            Dim enmStatus As WAIT_STATUS = pFunc()

            If enmStatus = WAIT_STATUS.SUCCESS Then
                '処理成功
                Return True
            End If

            If enmStatus = WAIT_STATUS.ERROR Then
                '処理エラー
                Return False
            End If

            'Application.DoEvents()は記述しない
            'スレッドをWindowsに返す
            Threading.Thread.Sleep(pintInterval)
        End While

        ' タイムアウト
        Return False
    End Function

#End Region

#Region "テスト待ち処理"

    ''' <summary>
    ''' テスト待ち処理
    ''' </summary>
    ''' <param name="pFunc">評価関数</param>
    ''' <param name="ptsTimeout">タイムアウト</param>
    ''' <param name="pintInterval">インターバル</param>
    Public Shared Sub WaitForTest(pFunc As Func(Of Boolean), ptsTimeout As TimeSpan, Optional pstrExceptionMessage As String = "テスト待ちのタイムアウトしました", Optional pintInterval As Integer = 50)
        Dim ret As Boolean = WaitForFunc(pFunc, ptsTimeout, pintInterval)
        If (ret = False) Then
            Throw New TestException(pstrExceptionMessage)
        End If
    End Sub

    ''' <summary>
    ''' テスト待ち処理
    ''' </summary>
    ''' <param name="pFunc">評価関数</param>
    ''' <param name="ptsTimeout">タイムアウト</param>
    ''' <param name="pintInterval">インターバル</param>
    Public Shared Sub WaitForTest(pFunc As Func(Of Object), ptsTimeout As TimeSpan, Optional pstrExceptionMessage As String = "テスト待ちのタイムアウトしました", Optional pintInterval As Integer = 50)
        Dim ret As Object = WaitForFunc(pFunc, ptsTimeout, pintInterval)
        If (ret Is Nothing) Then
            Throw New TestException(pstrExceptionMessage)
        End If
    End Sub

    ''' <summary>
    ''' テスト待ち処理
    ''' </summary>
    ''' <param name="pFunc">評価関数</param>
    ''' <param name="ptsTimeout">タイムアウト</param>
    ''' <param name="pintInterval">インターバル</param>
    Public Shared Sub WaitForTest(pFunc As Func(Of WAIT_STATUS), ptsTimeout As TimeSpan, Optional pstrExceptionMessage As String = "テスト待ちのタイムアウトしました", Optional pintInterval As Integer = 50)
        Dim ret As Boolean = WaitForFunc(pFunc, ptsTimeout, pintInterval)
        If (ret = False) Then
            Throw New TestException(pstrExceptionMessage)
        End If
    End Sub

#End Region
End Class

