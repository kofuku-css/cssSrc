Imports System
Imports System.Runtime.InteropServices
Imports System.Threading
Imports System.Windows.Forms
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Window

''' <summary>
''' WinForms を「別 STA スレッド + メッセージループ」で起動し、
''' MSTest のテストスレッドからは Invoke/BeginInvoke 経由で操作するためのホストです。
''' </summary>
''' <remarks>
''' - MSTest の実行スレッドは MTA になることが多く、WinForms を同一スレッドで直接操作すると例外/不具合になりがちです。
''' - そこで、UI を STA スレッドで起動し、テスト側は UI スレッドに処理を転送する構成とします。
''' </remarks>
Public NotInheritable Class UiAppHost
    Implements IDisposable

    Private mUiThread As Thread = Nothing
    Private mReady As ManualResetEventSlim = Nothing
    Private mfrmMain As Form = Nothing

    ''' <summary>
    ''' ファクトリメソッド
    ''' </summary>
    Private mfrmFactory As Func(Of Form)

#Region "コンストラクタ"
    ''' <summary>
    ''' コンストラクタ
    ''' コンストラクタはフォームのファクトリを受け取る
    ''' </summary>
    ''' <param name="pfrmFactory"></param>
    Public Sub New(pfrmFactory As Func(Of Form))
        mfrmFactory = pfrmFactory
    End Sub
#End Region

#Region "IDisposable"
    Public Sub Dispose() Implements IDisposable.Dispose
        ' TestCleanup で Stop() を呼ぶ想定だが、念のため Dispose でも停止する
        Try
            StopUI()
        Catch
            ' Dispose 内では例外を握りつぶす(二重例外でテスト基盤を不安定にしないため)
        End Try
    End Sub

#End Region

#Region "UIスレッドを起動しフォームを表示"
    ''' <summary>
    ''' UIスレッドを起動しフォームを表示
    ''' </summary>
    Public Sub StartUI()
        ' 既に起動済みであれば二重起動しない
        If Not mUiThread Is Nothing Then
            Return
        End If

        ' フォーム表示完了を待つための同期オブジェクトを作成
        mReady = New ManualResetEventSlim(False)

        ' UI 専用スレッドを作成(必ず STA)
        Dim expError As Exception = Nothing
        mUiThread = New Thread(Sub()
                                   Try
                                       ' WinForms の初期化(テンプレートに近い設定)
                                       Application.SetCompatibleTextRenderingDefault(False)

                                       ' UI スレッド内でフォーム生成
                                       mfrmMain = mfrmFactory()

                                       ' Shown イベントで「表示完了」を通知する
                                       AddHandler mfrmMain.Shown, Sub(sender, e)
                                                                      mReady.Set()
                                                                  End Sub

                                       ' メッセージループ開始(フォームが Close されるまで戻らない)
                                       Application.Run(mfrmMain)

                                   Catch ex As Exception
                                       ' UI スレッドの例外は、テストスレッド側で検出できるよう保持
                                       expError = ex
                                       Try
                                           mReady.Set()
                                       Catch
                                       End Try
                                   End Try

                               End Sub)
        mUiThread.IsBackground = True
        mUiThread.SetApartmentState(ApartmentState.STA)

        ' スレッド開始
        mUiThread.Start()

        ' フォームが表示完了するまで待機(タイムアウトは安全側に長め)
        If Not mReady.Wait(TimeSpan.FromSeconds(30)) Then
            Throw New TimeoutException("UI 起動がタイムアウトしました。フォームの生成/表示に失敗している可能性があります。")
        End If

        ' UI スレッド側で例外が発生していたら、ここでテストを失敗させる
        If expError IsNot Nothing Then
            Throw New InvalidOperationException("UI 起動中に例外が発生しました。", expError)
        End If
    End Sub
#End Region

#Region "UIスレッドを終了しフォームを終了"
    ''' <summary>
    ''' UIスレッドを終了しフォームを終了
    ''' </summary>
    Public Sub StopUI()
        ' まだ起動していない場合は何もしない
        If mUiThread Is Nothing Then
            Return
        End If

        ' 可能であれば UI スレッド上で Close を実行する
        InvokeOnUi(Sub()
                       If (mfrmMain IsNot Nothing) AndAlso (mfrmMain.IsDisposed = False) Then
                           mfrmMain.Close()
                       End If
                   End Sub)

        ' UI スレッドの終了を待機
        If Not mUiThread.Join(TimeSpan.FromSeconds(5)) Then
            ' ここで Abort は避け、例外として通知する(環境依存のため)
            Throw New TimeoutException("UI スレッドの終了待機がタイムアウトしました。")
        End If

        ' 後片付け
        mUiThread = Nothing
    End Sub
#End Region

#Region "UIスレッド上での同期実行"
    ''' <summary>
    ''' UI スレッド上で Action を非同期実行します。
    ''' </summary>
    Public Sub InvokeOnUi(ByVal action As Action)
        If action Is Nothing Then
            Throw New ArgumentNullException(NameOf(action))
        End If
        If mfrmMain Is Nothing Then
            Throw New InvalidOperationException("UI が起動していません。Start() を先に呼び出してください。")
        End If

        ' InvokeRequired の場合は UI スレッドへ転送
        If mfrmMain.InvokeRequired Then
            mfrmMain.Invoke(action)
        Else
            action()
        End If
    End Sub
#End Region

#Region "フォーム取得"
    ''' <summary>
    ''' フォームを取得する
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="pstrTitle"></param>
    ''' <returns></returns>
    Public Function GetForm(Of T As Form)(pstrTitle As String) As T
        For Each frm As T In Application.OpenForms.OfType(Of T)()
            If (String.IsNullOrWhiteSpace(pstrTitle)) Then
                If (frm.IsHandleCreated AndAlso frm.Visible) Then
                    Return frm
                Else
                    Return Nothing
                End If
            Else
                If frm.Text = pstrTitle & " (新Ver)" Then
                    If (frm.IsHandleCreated AndAlso frm.Visible) Then
                        Return frm
                    Else
                        Return Nothing
                    End If
                End If
            End If
        Next

        Return Nothing
    End Function
#End Region

End Class

