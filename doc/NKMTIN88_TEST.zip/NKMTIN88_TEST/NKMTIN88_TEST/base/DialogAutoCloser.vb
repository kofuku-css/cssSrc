Option Strict On
Option Explicit On

Imports System
Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports System.ServiceModel.Security
Imports System.Text
Imports System.Threading
Imports System.Windows.Forms


''' <summary>
''' メッセージボックス等(Win32 ダイアログ #32770)を自動で閉じるユーティリティです。
''' </summary>
''' <remarks>
''' MessageBoxの表示対応
''' テストを自動化するため、プロセス内に出現したダイアログを検出し、「はい」→(見つからなければ)「OK」を優先してクリックします。
''' </remarks>
Public NotInheritable Class DialogAutoCloser
    Implements IDisposable

#Region "Win32 API"
    Private Delegate Function EnumWindowsProc(ByVal hWnd As IntPtr, ByVal lParam As IntPtr) As Boolean
    Private Delegate Function EnumChildProc(ByVal hWnd As IntPtr, ByVal lParam As IntPtr) As Boolean

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function EnumWindows(ByVal lpEnumFunc As EnumWindowsProc, ByVal lParam As IntPtr) As Boolean
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function EnumChildWindows(ByVal hWndParent As IntPtr, ByVal lpEnumFunc As EnumChildProc, ByVal lParam As IntPtr) As Boolean
    End Function

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Private Shared Function GetClassName(ByVal hWnd As IntPtr, ByVal lpClassName As StringBuilder, ByVal nMaxCount As Integer) As Integer
    End Function

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Private Shared Function GetWindowText(ByVal hWnd As IntPtr, ByVal lpString As StringBuilder, ByVal nMaxCount As Integer) As Integer
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function GetWindowThreadProcessId(ByVal hWnd As IntPtr, ByRef lpdwProcessId As Integer) As Integer
    End Function

    <DllImport("user32.dll", SetLastError:=True)>
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Private Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, wParam As IntPtr, lParam As StringBuilder) As IntPtr
    End Function

    Private Const WM_LBUTTONDOWN As UInteger = &H201UI
    Private Const WM_LBUTTONUP As UInteger = &H202UI
    Private Const BM_CLICK As UInteger = &HF5UI
#End Region

#Region "インスタンス変数"
    Private ReadOnly maryButtonTexts As String()    'ボタンテキストが合致する候補リスト
    Private ReadOnly mtsTimeout As TimeSpan         'タイムアウト時間   
    Private ReadOnly mstrMessage As String          'メッセージ

    Private mThread As Thread = Nothing
    Private mblnResult As Boolean = False
#End Region

#Region "コンストラクタ"
    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="psaryButtonTexts">ボタンテキストが合致する候補リスト</param>
    ''' <param name="ptsTimeout">タイムアウト時間</param>
    ''' <param name="pstrMessage">メッセージ</param>
    Private Sub New(ByVal psaryButtonTexts As String(), ByVal ptsTimeout As TimeSpan, pstrMessage As String)
        maryButtonTexts = psaryButtonTexts
        mtsTimeout = ptsTimeout
        mstrMessage = pstrMessage
    End Sub
#End Region

#Region "IDisposable"
    Public Sub Dispose() Implements IDisposable.Dispose
        Try
            If mThread IsNot Nothing Then
                mThread.Join(TimeSpan.FromSeconds(3))
            End If
        Catch
        End Try
        mThread = Nothing

        If (mblnResult = False) Then
            If (String.IsNullOrWhiteSpace(mstrMessage)) Then
                Throw New TestException("メッセージボックスが見つかりませんでした。")
            Else
                Throw New TestException(String.Format("メッセージボックスが見つかりませんでした。メッセージ：{0}", mstrMessage))
            End If
        End If
    End Sub

#End Region

#Region "factory"
    ''' <summary>
    ''' 発生するダイアログを閉じる想定の既定設定で開始します。
    ''' </summary>
    ''' <param name="ptsTimeout">タイムアウト時間</param>
    ''' <param name="pstrMessage">メッセージ</param>
    Public Shared Function ResultForStartPositive(ByVal ptsTimeout As TimeSpan, Optional pstrMessage As String = "") As DialogAutoCloser
        Dim texts As String() = New String() {"はい", "はい(&Y)", "Yes", "ＯＫ", "OK"}
        Dim inst As New DialogAutoCloser(texts, ptsTimeout, pstrMessage)

        inst.Start()
        Return inst
    End Function

    ''' <summary>
    ''' 発生するダイアログを閉じる想定の既定設定で開始します。
    ''' </summary>
    ''' <param name="ptsTimeout">タイムアウト時間</param>
    ''' <param name="pstrMessage">メッセージ</param>
    Public Shared Function ResultForNegative(ByVal ptsTimeout As TimeSpan, Optional pstrMessage As String = "") As DialogAutoCloser
        Dim texts As String() = New String() {"いいえ", "いいえ(&N)", "No", "キャンセル", "Cancel"}
        Dim inst As New DialogAutoCloser(texts, ptsTimeout, pstrMessage)

        inst.Start()
        Return inst
    End Function
#End Region

#Region "public method"
    ''' <summary>バックグラウンド監視を開始します。</summary>
    Public Sub Start()
        '成否フラグの初期化
        mblnResult = False

        If Not mThread Is Nothing Then
            Return
        End If

        'スレッド開始
        mThread = New Thread(Sub()
                                 ' 指定時間、一定間隔で「ダイアログが出現したらボタンを押す」を繰り返す
                                 Dim sw As Stopwatch = Stopwatch.StartNew()
                                 Do While (sw.Elapsed < mtsTimeout)
                                     '条件に合致したらダイアログを閉じて終了
                                     Dim blnRet As Boolean = Me.CloseMsgBoxIfConditions()
                                     If (blnRet) Then
                                         '成功
                                         mblnResult = True
                                         Return
                                     End If

                                     Thread.Sleep(50)
                                 Loop

                                 ' タイムアウト：強制的にメッセージボックスを閉じて次に進める 
                                 Me.ForceCloseMsgBox()
                             End Sub)

        mThread.IsBackground = True
        mThread.Start()
    End Sub
#End Region

#Region "private method"
    ''' <summary>
    ''' 条件に合致するメッセージボックスがあれば閉じる
    ''' </summary>
    Private Function CloseMsgBoxIfConditions() As Boolean
        Dim result As Boolean = False

        ' 同じプロセスのプロセス内のトップレベルウィンドウを走査し、クラス "#32770"(標準ダイアログ) を探す
        EnumWindows(Function(hWnd, lParam)
                        ' 対象プロセスのウィンドウか確認
                        Dim pid As Integer = 0
                        GetWindowThreadProcessId(hWnd, pid)     'ウィンドウを作成したプロセスのIDを取得する 
                        If pid <> Process.GetCurrentProcess().Id Then
                            '列挙を継続
                            Return True
                        End If

                        ' クラス名を取得して、"#32770"だったらボタンを探索して押下
                        Dim cls As String = Me.GetClassNameString(hWnd)        '指定したウィンドウが属するクラスの名前を取得
                        If StringComparer.Ordinal.Equals(cls, "#32770") Then
                            If Not String.IsNullOrWhiteSpace(mstrMessage) Then
                                Dim dialogText As String = Me.FindFirstStaticText(hWnd)
                                If Not StringComparer.Ordinal.Equals(dialogText, mstrMessage) Then
                                    'メッセージが異なる場合はスルー
                                    '列挙を継続
                                    Return True
                                End If
                            End If

                            ' ダイアログが見つかったら、子のボタンを探索して押下
                            result = Me.ClickButtonInDialog(hWnd)
                            If (result) Then
                                Return False ' ウィンドウ列挙を中断
                            End If
                        End If

                        '列挙を継続
                        Return True
                    End Function, IntPtr.Zero)

        Return result
    End Function

    ''' <summary>
    ''' 同じプロセスのメッセージボックスを閉じる
    ''' </summary>
    Private Sub ForceCloseMsgBox()
        ' 最後の手段：WM_CLOSE
        Const WM_CLOSE As UInteger = &H10UI

        EnumWindows(Function(hWnd, lParam)
                        Dim pid As Integer = 0
                        GetWindowThreadProcessId(hWnd, pid)
                        If pid <> Process.GetCurrentProcess().Id Then
                            '列挙を継続
                            Return True
                        End If

                        Dim cls As String = Me.GetClassNameString(hWnd)
                        If StringComparer.Ordinal.Equals(cls, "#32770") Then
                            ' 最後の手段：WM_CLOSE
                            SendMessage(hWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero)
                            Return False
                        End If

                        '列挙を継続
                        Return True
                    End Function, IntPtr.Zero)
    End Sub

    ''' <summary>
    ''' ダイアログ内のメッセージを取得する
    ''' </summary>
    ''' <param name="dialogHwnd"></param>
    ''' <returns></returns>
    Private Function FindFirstStaticText(dialogHwnd As IntPtr) As String
        Dim result As String = Nothing

        EnumChildWindows(dialogHwnd,
            Function(hWnd, lParam)
                If result IsNot Nothing Then Return False

                ' 子ウィンドウのクラス名を取得
                Dim cls As String = Me.GetClassNameString(hWnd)        '指定したウィンドウが属するクラスの名前を取得
                If Not StringComparer.Ordinal.Equals(cls, "Static") Then
                    Return True
                End If

                ' 通常、MessageBox の本文は最初の Static に入ることが多い
                Dim text = Me.GetWindowTextString(hWnd)

                If String.IsNullOrEmpty(text) Then
                    ' 必要なら WM_GETTEXT も試す
                    text = GetWindowTextByWmGetText(hWnd)
                End If

                If Not String.IsNullOrEmpty(text) Then
                    result = text
                    Return False ' これ以上の子ウィンドウ列挙を中断
                End If

                '列挙を継続
                Return True
            End Function, IntPtr.Zero)

        Return result
    End Function

    ''' <summary>
    ''' ボタンを見つけたら 1 回だけクリックする(クリックできたら以降の探索は不要)
    ''' </summary>
    ''' <param name="dialogHwnd"></param>
    Private Function ClickButtonInDialog(ByVal dialogHwnd As IntPtr) As Boolean
        Dim result As Boolean = False
        ' 
        EnumChildWindows(dialogHwnd,
                             Function(hWnd, lParam)
                                 ' 子ウィンドウのクラス名を取得
                                 Dim cls As String = Me.GetClassNameString(hWnd)        '指定したウィンドウが属するクラスの名前を取得
                                 If Not StringComparer.Ordinal.Equals(cls, "Button") Then
                                     Return True
                                 End If

                                 ' ボタンの表示テキストを取得
                                 Dim text As String = Me.GetWindowTextString(hWnd)

                                 ' 優先順位に従ってクリック対象か判断
                                 For Each target As String In maryButtonTexts
                                     If StringComparer.OrdinalIgnoreCase.Equals(text, target) Then
                                         ' クリック(マウスメッセージ送信)
                                         '-- MOD(ST)
                                         '-- テスト中にマウスを動作させても誤動作しないように対応
                                         'SendMessage(hWnd, WM_LBUTTONDOWN, IntPtr.Zero, IntPtr.Zero)
                                         'SendMessage(hWnd, WM_LBUTTONUP, IntPtr.Zero, IntPtr.Zero)
                                         SendMessage(hWnd, BM_CLICK, IntPtr.Zero, IntPtr.Zero)
                                         '-- MOD(END)

                                         result = True
                                         Return False ' これ以上の子ウィンドウ列挙を中断
                                     End If
                                 Next

                                 '列挙を継続
                                 Return True
                             End Function, IntPtr.Zero)
        Return result
    End Function

    ''' <summary>
    ''' 指定したウィンドウが属するクラスの名前を取得
    ''' </summary>
    ''' <param name="hWnd"></param>
    ''' <returns></returns>
    Private Function GetClassNameString(ByVal hWnd As IntPtr) As String
        Dim sb As New StringBuilder(256)
        GetClassName(hWnd, sb, sb.Capacity)
        Return sb.ToString()
    End Function

    ''' <summary>
    ''' 表示テキストを取得
    ''' </summary>
    ''' <param name="hWnd"></param>
    ''' <returns></returns>
    Private Function GetWindowTextString(ByVal hWnd As IntPtr) As String
        Dim sb As New StringBuilder(512)
        GetWindowText(hWnd, sb, sb.Capacity)
        Return sb.ToString()
    End Function

    ' WM_GETTEXT を使う場合（必要なら）
    Private Const WM_GETTEXT As Integer = &HD
    Private Const WM_GETTEXTLENGTH As Integer = &HE

    Private Function GetWindowTextByWmGetText(hWnd As IntPtr) As String
        ' GetWindowText が取りにくいケース向け（必要時のみ）
        Dim lenPtr = SendMessage(hWnd, WM_GETTEXTLENGTH, IntPtr.Zero, IntPtr.Zero)
        Dim len = lenPtr.ToInt32()
        If len <= 0 Then Return String.Empty

        Dim sb As New StringBuilder(len + 1)
        SendMessage(hWnd, WM_GETTEXT, CType(sb.Capacity, IntPtr), sb)
        Return sb.ToString()
    End Function

#End Region

End Class
