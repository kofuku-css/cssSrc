﻿''' <summary>
''' テスト処理例外定義
''' </summary>
Public Class TestException
    Inherits Exception

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="pstrMessage"></param>
    Sub New(ByVal pstrMessage As String)
        MyBase.New(pstrMessage)
    End Sub
End Class
