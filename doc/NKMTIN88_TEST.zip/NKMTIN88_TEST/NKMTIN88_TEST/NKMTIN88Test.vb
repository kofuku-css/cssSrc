Imports System
Imports System.Data
Imports System.Reflection
Imports System.Threading
Imports System.Windows.Forms
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Comsystem.Common
Imports Comsystem.DataAccess
Imports NKMTIN88
Imports NKSRGK001
Imports NKCOMMON

''' <summary>
''' 銀行マスタ（NKMTIN88）のE2Eテスト（WinFormsを直接インスタンス化）
''' </summary>
''' <remarks>
''' - UiAppHost（WinFormsTest雛形の共通処理）を用いて、別STAスレッドでフォームを起動します。
''' - 画面操作はUIスレッドへInvokeして行い、DB反映結果は「画面で再取得して一致確認」を基本とします。
''' - 追加の二重化検証として、ODPEx で Oracle に直接 SELECT して確認します（可能な範囲）。
''' </remarks>
<TestClass>
Public Class NKMTIN88Test

#Region "private field"

    ''' <summary>
    ''' ホストアダプタ
    ''' </summary>
    Private mHost As UiAppHost = Nothing

    ''' <summary>
    ''' このテストクラス内で確保した銀行コード（TestCleanupで必ず原状復帰に利用）
    ''' </summary>
    Private mintTestBankCode As Integer? = Nothing

#End Region

#Region "TestInitialize / TestCleanup"

    ''' <summary>
    ''' 各テスト開始時に、銀行マスタ画面を起動します。
    ''' </summary>
    <TestInitialize>
    Public Sub TestInitialize()
        'UIホストを生成（対象：銀行マスタ登録画面）
        mHost = New UiAppHost(Function() New frmNKMTIN88())

        'UIを起動（別 STA スレッド + メッセージループ）
        mHost.StartUI()

        '画面が表示状態になるまで待機（起動失敗を早期に検知）
        Dim frm As frmNKMTIN88 = Nothing
        UtlTimeout.WaitForTest(Function()
                                   frm = mHost.GetForm(Of frmNKMTIN88)("銀行マスタ登録")
                                   Return frm IsNot Nothing
                               End Function,
                               TimeSpan.FromSeconds(10),
                               "銀行マスタ登録画面の起動確認")
    End Sub

    ''' <summary>
    ''' 各テスト終了時に、画面を終了し、テストデータを必ず削除して原状復帰します（失敗時も含む）。
    ''' </summary>
    <TestCleanup>
    Public Sub TestCleanup()

        'テストで使用した銀行コードがあれば、DBから削除して原状復帰する
        Try
            If mintTestBankCode.HasValue Then
                Me.EnsureBankDeleted(mintTestBankCode.Value)
            End If
        Catch ex As Exception
            ' Cleanupでの削除失敗は、原因切り分けのため例外として通知する
            Throw New AssertFailedException("TestCleanup でテストデータ削除に失敗しました。", ex)
        Finally
            mintTestBankCode = Nothing
        End Try

        'UIを終了（終了確認ダイアログが出る場合にも備えて自動クローズを入れる）
        Try
            If mHost IsNot Nothing Then
                'メッセージボックス対応
                Using DialogAutoCloser.ResultForStartPositive(TimeSpan.FromSeconds(5))
                    mHost.StopUI()
                End Using
            End If
        Finally
            mHost = Nothing
        End Try
    End Sub

#End Region

#Region "TestMethod"
    ''' <summary>
    ''' T1_銀行コード参照画面を表示できること（F1:参照）
    ''' </summary>
    <TestMethod>
    Public Sub T1_銀行コード参照画面_表示確認()
        'メイン画面を取得
        Dim frm As frmNKMTIN88 = mHost.GetForm(Of frmNKMTIN88)("銀行マスタ登録")
        Assert.IsNotNull(frm, "メイン画面が取得できません。")

        'F1キー押下
        'モーダルのダイアログ表示
        mHost.InvokeOnUi(Sub()
                             frm.Activate()
                             SendKeys.Send("{F1}")     'モーダル表示なので非同期実行
                         End Sub)

        '参照画面が表示されるまで一定時間待機
        '同じUIスレッドで確認待ちとすると処理を占有するため、テスト実行スレッドで確認待ちとする
        Dim dlg As frmNKSRGK001 = Nothing
        UtlTimeout.WaitForTest(Function()
                                   dlg = mHost.GetForm(Of frmNKSRGK001)("銀行検索")
                                   Return dlg IsNot Nothing
                               End Function, TimeSpan.FromSeconds(5), "銀行検索ダイアログの表示確認")

        '参照画面の確認
        mHost.InvokeOnUi(Sub()
                             '参照画面を閉じる   
                             dlg.Close()
                         End Sub)
    End Sub

    ''' <summary>
    ''' T2_銀行マスタ CRUD（INSERT/UPDATE/DELETE） + 全角数字/全角記号を含む入力の一致確認
    ''' </summary>
    <TestMethod>
    Public Sub T2_銀行マスタ_CRUD_全角入力_一致確認()

        'メイン画面を取得
        Dim frm As frmNKMTIN88 = mHost.GetForm(Of frmNKMTIN88)("銀行マスタ登録")
        Assert.IsNotNull(frm, "メイン画面が取得できません。")

        '衝突しない銀行コードを自動選定（9000～9999 の範囲）
        Dim bnkcd As Integer = AllocateBankCode9000To9999()
        mintTestBankCode = bnkcd

        '登録用（INSERT）入力値（BNKNM/BNKKANA に全角数字/全角記号を含める）
        Dim insertName As String = "テスト銀行１２３４５！＃＄％＆"
        Dim insertKana As String = "テスト１２！＃"

        '更新用（UPDATE）入力値（INSERT と別値で確認）
        Dim updateName As String = "更新銀行９８７６５＠＊（）"
        Dim updateKana As String = "更新９８＠＊"

        ' ---------------------------------------
        ' INSERT
        ' ---------------------------------------
        '銀行コード入力 → 新規
        mHost.InvokeOnUi(Sub()
                         End Sub)

        mHost.InvokeOnUi(Sub()
                             frm.iedtBnkCode.Text = bnkcd.ToString()
                             frm.iedtBnkCode.Focus()
                             SendKeys.SendWait("{ENTER}")   '送って処理されるまで待つ(SendKeys.Send + Application.DoEvents()と等価)
                             UtlTimeout.WaitForTest(Function()
                                                        Return (frm.iedtBnkName.Text = String.Empty) And (frm.iedtBnkKana.Text = String.Empty) And (frm.iedtStatus.Text = "登録")
                                                    End Function, TimeSpan.FromSeconds(5), "新規の表示確認が出来ませんでした")

                             '銀行名/銀行名カナを入力
                             frm.iedtBnkName.Text = insertName
                             frm.iedtBnkKana.Text = insertKana

                             '登録（F5相当：ActionUpdate）を実行（確認/完了メッセージを自動押下）
                             SendKeys.Send("{F5}")  'メッセージボックス対応の対応のため非同期実行
                         End Sub)
        'メッセージボックス対応
        Using DialogAutoCloser.ResultForStartPositive(TimeSpan.FromSeconds(3))
        End Using
        Using DialogAutoCloser.ResultForStartPositive(TimeSpan.FromSeconds(3))
        End Using


        '画面で再取得して一致確認（仕様：画面で再取得が基本）
        AssertBankOnScreen(frm, bnkcd, insertName, insertKana)

        'Oracle に直接 SELECT して二重化検証（可能な範囲）
        AssertBankOnDatabase(bnkcd, insertName, insertKana)


        ' ---------------------------------------
        ' CLEAR
        ' ---------------------------------------
        mHost.InvokeOnUi(Sub()
                             SendKeys.Send("{F8}")  'メッセージボックス対応の対応のため非同期実行
                         End Sub)
        'メッセージボックス対応
        Using DialogAutoCloser.ResultForStartPositive(TimeSpan.FromSeconds(3))
        End Using
        mHost.InvokeOnUi(Sub()
                             UtlTimeout.WaitForTest(Function()
                                                        Return (frm.iedtBnkName.Text = String.Empty) And (frm.iedtBnkKana.Text = String.Empty) And (frm.iedtStatus.Text = String.Empty)
                                                    End Function, TimeSpan.FromSeconds(5), "キャンセルの表示確認が出来ませんでした")
                         End Sub)


        ' ---------------------------------------
        ' UPDATE
        ' ---------------------------------------
        ' 再取得（Updateモードへ）
        mHost.InvokeOnUi(Sub()
                             'データの呼び出し
                             frm.iedtBnkCode.Text = bnkcd.ToString()
                             frm.iedtBnkCode.Focus()
                             SendKeys.SendWait("{ENTER}")   '送って処理されるまで待つ(SendKeys.Send + Application.DoEvents()と等価)
                             UtlTimeout.WaitForTest(Function()
                                                        Return frm.iedtBnkName.Text = insertName And frm.iedtBnkKana.Text = insertKana
                                                    End Function, TimeSpan.FromSeconds(5), "データの呼び出しの表示確認が出来ませんでした")

                             '更新値を入力
                             frm.iedtBnkName.Text = updateName
                             frm.iedtBnkKana.Text = updateKana

                             '登録（更新）を実行（確認/完了メッセージを自動押下）
                             SendKeys.Send("{F5}")  'メッセージボックス対応の対応のため非同期実行
                         End Sub)

        'メッセージボックス対応
        Using DialogAutoCloser.ResultForStartPositive(TimeSpan.FromSeconds(3))
        End Using
        Using DialogAutoCloser.ResultForStartPositive(TimeSpan.FromSeconds(3))
        End Using

        '画面で再取得して一致確認
        AssertBankOnScreen(frm, bnkcd, updateName, updateKana)

        'Oracle に直接 SELECT して二重化検証
        AssertBankOnDatabase(bnkcd, updateName, updateKana)
        Return

        ' ---------------------------------------
        ' DELETE
        ' ---------------------------------------
        '再取得（削除対象を画面にロード）
        mHost.InvokeOnUi(Sub()
                             frm.iedtBnkCode.Text = bnkcd.ToString()
                             frm.iedtBnkCode.Focus()
                             SendKeys.SendWait("{ENTER}") '送って処理されるまで待つ(SendKeys.Send + Application.DoEvents()と等価)
                             UtlTimeout.WaitForTest(Function()
                                                        Return frm.iedtBnkName.Text = updateName And frm.iedtBnkKana.Text = updateKana
                                                    End Function, TimeSpan.FromSeconds(5), "表示確認が出来ませんでした")
                             ' 削除（Ctrl+Alt+F6 キーの送信)
                             SendKeys.Send("^%{F6}")   'メッセージボックス対応の対応のため非同期実行
                         End Sub)

        'メッセージボックス対応
        Using DialogAutoCloser.ResultForStartPositive(TimeSpan.FromSeconds(3))
        End Using
        Using DialogAutoCloser.ResultForStartPositive(TimeSpan.FromSeconds(3))
        End Using

        'DB に存在しないこと
        Assert.IsFalse(IsBankExists(bnkcd), "削除後もDBにデータが残っています。")

        'cleanup対象を解除（TestCleanup側の二重削除は許容だが、ここで明確にしておく）
        mintTestBankCode = Nothing
    End Sub

#End Region

#Region "private helper - 画面操作/検証"

    ''' <summary>
    ''' 画面で再取得して、入力値が一致することを確認します。
    ''' </summary>
    Private Sub AssertBankOnScreen(frm As frmNKMTIN88, bnkcd As Integer, expName As String, expKana As String)

        ' Act: 銀行コード入力 → 再取得（Enter相当）
        mHost.InvokeOnUi(Sub()
                             frm.iedtBnkCode.Text = bnkcd.ToString()
                             frm.iedtBnkCode.Focus()
                             SendKeys.SendWait("{ENTER}")

                             '取得した内容が反映されるまで待機してから一致確認
                             UtlTimeout.WaitForTest(Function()
                                                        Return frm.iedtBnkName.Text = expName AndAlso frm.iedtBnkKana.Text = expKana
                                                    End Function,
                               TimeSpan.FromSeconds(10),
                               "画面再取得の一致確認")
                         End Sub)
    End Sub

#End Region

#Region "private helper - DB操作/検証"

    ''' <summary>
    ''' 9000～9999 の範囲で未使用の銀行コードを選定します。
    ''' </summary>
    Private Shared Function AllocateBankCode9000To9999() As Integer

        ' Arrange: DBアクセス用 ODPEx を生成（接続文字列はアプリと同一ソース：NKIni）
        Dim odpex As ODPEx = CreateOdpEx()

        ' Arrange: 既存コードをまとめて取得し、衝突回避を高速化
        Dim ds As New DataSet()
        Dim sql As String = "SELECT BNKCD FROM ""銀行マスタ"" WHERE BNKCD BETWEEN 9000 AND 9999"
        odpex.Fill(ds, "BANKS", sql)

        Dim used As New Collections.Generic.HashSet(Of Integer)()
        If ds.Tables.Contains("BANKS") Then
            For Each dr As DataRow In ds.Tables("BANKS").Rows
                used.Add(Convert.ToInt32(dr("BNKCD")))
            Next
        End If

        ' Arrange: 先頭から未使用を探す（必要なら乱択に変更可）
        For code As Integer = 9000 To 9999
            If Not used.Contains(code) Then
                Return code
            End If
        Next

        Throw New AssertFailedException("9000～9999 の範囲で未使用の銀行コードが見つかりませんでした。")
    End Function

    ''' <summary>
    ''' 指定コードの銀行マスタが存在するかを確認します。
    ''' </summary>
    Private Shared Function IsBankExists(bnkcd As Integer) As Boolean
        Dim odpex As ODPEx = CreateOdpEx()

        Dim ds As New DataSet()
        Dim sql As String = String.Format("SELECT BNKCD FROM ""銀行マスタ"" WHERE BNKCD = {0}", bnkcd)

        Return (odpex.Fill(ds, "BANK", sql) >= 1)
    End Function

    ''' <summary>
    ''' DBに直接SELECTして一致確認します（BNKNM/BNKKANA）。
    ''' </summary>
    Private Shared Sub AssertBankOnDatabase(bnkcd As Integer, expName As String, expKana As String)
        Dim odpex As ODPEx = CreateOdpEx()

        Dim ds As New DataSet()
        Dim sql As String = String.Format("SELECT BNKNM, BNKKANA FROM ""銀行マスタ"" WHERE BNKCD = {0}", bnkcd)

        Dim count As Integer = odpex.Fill(ds, "BANK", sql)
        Assert.IsTrue(count >= 1, "DBにデータが存在しません（登録/更新が反映されていない可能性）。")

        Dim dr As DataRow = ds.Tables("BANK").Rows(0)
        Assert.AreEqual(expName, Convert.ToString(dr("BNKNM")), "DBのBNKNMが一致しません。")
        Assert.AreEqual(expKana, Convert.ToString(dr("BNKKANA")), "DBのBNKKANAが一致しません。")
    End Sub

    ''' <summary>
    ''' テストデータ（指定銀行コード）を必ず削除します（存在しない場合は何もしません）。
    ''' </summary>
    Private Shared Sub EnsureBankDeleted(bnkcd As Integer)

        ' Arrange: DBアクセス用 ODPEx
        Dim odpex As ODPEx = CreateOdpEx()

        ' Arrange: 対象行を取得
        Dim ds As New DataSet()
        Dim sql As String = String.Format("SELECT * FROM ""銀行マスタ"" WHERE BNKCD = {0}", bnkcd)

        If odpex.Fill(ds, "銀行マスタ", sql) <= 0 Then
            ' 既に存在しない場合は何もしない
            Exit Sub
        End If

        ' Act: 対象行を削除としてマーク
        ds.Tables("銀行マスタ").Rows(0).Delete()

        ' Act: 反映（NKMTIN88側の更新方式に合わせてUpdateArrayを使用）
        odpex.ResetUpdateArray()
        odpex.AddUpdateArray(ds, "銀行マスタ", sql)

        ' Assert: 反映成功を確認（失敗した場合は例外として上位に通知）
        If Not odpex.CommitUpdateArray() Then
            Throw New InvalidOperationException("ODPEx.CommitUpdateArray に失敗しました。")
        End If
    End Sub

    ''' <summary>
    ''' ODPEx を生成し、アプリと同じ接続文字列を設定して返します。
    ''' </summary>
    Private Shared Function CreateOdpEx() As ODPEx
        Dim odpex As New ODPEx()
        odpex.ConnectionString = NKIni.GetConnectionString()
        Return odpex
    End Function

#End Region

End Class