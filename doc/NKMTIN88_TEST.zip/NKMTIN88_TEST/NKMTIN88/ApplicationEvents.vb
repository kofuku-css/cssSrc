﻿Namespace My
    ' 次のイベントは MyApplication に対して利用できます:
    ' Startup:アプリケーションが開始されたとき、スタートアップ フォームが作成される前に発生します。
    ' Shutdown:アプリケーション フォームがすべて閉じられた後に発生します。このイベントは、アプリケーションが異常終了したときには発生しません。
    ' UnhandledException:ハンドルされない例外がアプリケーションで発生したときに発生します。
    ' StartupNextInstance:単一インスタンス アプリケーションが起動され、それが既にアクティブであるときに発生します。 
    ' NetworkAvailabilityChanged:ネットワーク接続が接続されたとき、または切断されたときに発生します。
    Partial Friend Class MyApplication
        Private Sub MyApplication_Startup(sender As Object, e As Microsoft.VisualBasic.ApplicationServices.StartupEventArgs) Handles Me.Startup
            #If DEBUG Then
                Comsystem.Forms.FormSupport.AddExceptionEventHandlerWithContinue()
            #Else
                Comsystem.Forms.FormSupport.AddExceptionEventHandler()
#End If

            Dim frm As New frmNKMTIN88

            'コマンドライン引数取得
            'If (0 < Args.Length) Then
            '    frm.UserId =  = ConvertEx.ToInt(Args(0))
            'End If
            If (e.CommandLine.Count > 0) Then
                frm.UserId = Comsystem.Common.ConvertEx.ToInt(e.CommandLine(0))
            End If

            'アプリケーションの起動・実行
            System.Windows.Forms.Application.Run(frm)

            ’アプリケーションの終了で、Application.Runから抜けてくる
            ’Cancel = Trueでアプリケーションの終了
            e.Cancel = True
        End Sub
    End Class
End Namespace
