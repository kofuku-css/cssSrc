﻿Imports GrapeCity.Win.Bars    '//追加(2017/09/28 10:47:07)
Imports GrapeCity.Win.Input.Interop

Imports System.Text

Imports Comsystem.Common
Imports Comsystem.Constants
Imports Comsystem.DataAccess
Imports Comsystem.Forms
Imports Comsystem.Forms.Controls

Imports NKCOMMON
Imports NKSRKM001
Imports DateTimeEX = Comsystem.Common.DateTimeEx

''' -----------------------------------------------------------------------------
''' Project	 : NKMTIN91
''' Class	 : frmNKMTIN91
''' 
''' -----------------------------------------------------------------------------
''' <summary>
'''   科目登録
''' </summary>
''' <remarks>
''' </remarks>
''' <history>
'''		[izumitani]		2009/07/15	Added	Ctrl+Alt+F6 動作不良対応
''' </history>
''' -----------------------------------------------------------------------------
Public Class frmNKMTIN91 
    Inherits Comsystem.Forms.Controls.BaseFormWithInputMan

#Region " Windows フォーム デザイナで生成されたコード "

    Public Sub New()
        MyBase.New()

        ' この呼び出しは Windows フォーム デザイナで必要です。
        InitializeComponent()

        ' InitializeComponent() 呼び出しの後に初期化を追加します。
		FormSupport.InitializeForm(Me)
		MyBase.InitializeBaseFormWithInputMan(Me)

    End Sub

    ' Form は、コンポーネント一覧に後処理を実行するために dispose をオーバーライドします。
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    ' メモ : 以下のプロシージャは、Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使って変更してください。  
    ' コード エディタを使って変更しないでください。
	Friend WithEvents ifkMain As GrapeCity.Win.Bars.GcClassicFunctionKey
	Friend WithEvents icntHead As GrapeCity.Win.Containers.GcContainer
	Friend WithEvents iedtStatus As GrapeCity.Win.Input.Interop.Edit
	Friend WithEvents iedtKmkCode As GrapeCity.Win.Input.Interop.Edit
	Friend WithEvents icntMain As GrapeCity.Win.Containers.GcContainer
	Friend WithEvents iedtKmkName As GrapeCity.Win.Input.Interop.Edit
	Friend WithEvents iedtPCNO As GrapeCity.Win.Input.Interop.Edit
    Friend WithEvents chkJigyoNoRenkeiFlg As CheckBox
    Friend WithEvents iedtWRTDT As GrapeCity.Win.Input.Interop.Edit
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ifkMain = New GrapeCity.Win.Bars.GcClassicFunctionKey()
        Me.icntHead = New GrapeCity.Win.Containers.GcContainer()
        Me.iedtPCNO = New GrapeCity.Win.Input.Interop.Edit()
        Me.iedtWRTDT = New GrapeCity.Win.Input.Interop.Edit()
        Me.iedtStatus = New GrapeCity.Win.Input.Interop.Edit()
        Me.iedtKmkCode = New GrapeCity.Win.Input.Interop.Edit()
        Me.icntMain = New GrapeCity.Win.Containers.GcContainer()
        Me.chkJigyoNoRenkeiFlg = New System.Windows.Forms.CheckBox()
        Me.iedtKmkName = New GrapeCity.Win.Input.Interop.Edit()
        CType(Me.BaseStatusBarPanelMessage1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BaseStatusBarPanelMessage2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BaseStatusBarPanelProgress, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BaseStatusBarPanelDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BaseStatusBarPanelTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BaseProgressBar.SuspendLayout()
        Me.icntHead.SuspendLayout()
        CType(Me.iedtPCNO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iedtWRTDT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iedtStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.iedtKmkCode, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.icntMain.SuspendLayout()
        CType(Me.iedtKmkName, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BaseStatusBar
        '
        Me.BaseStatusBar.Location = New System.Drawing.Point(0, 619)
        Me.BaseStatusBar.Size = New System.Drawing.Size(924, 22)
        '
        'BaseStatusBarPanelMessage1
        '
        Me.BaseStatusBarPanelMessage1.Width = 517
        '
        'BaseProgressBar
        '
        Me.BaseProgressBar.Location = New System.Drawing.Point(712, 716)
        '
        'ifkMain
        '
        Me.ifkMain.KeySets.Remove("Default")
        Me.ifkMain.KeySets.Add("Default", New GrapeCity.Win.Bars.KeySet(New GrapeCity.Win.Bars.KeyItem() {New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 0, True, System.Drawing.Color.Empty, -1, "F1 検索", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 1, False, System.Drawing.Color.Empty, -1, "F2", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 2, False, System.Drawing.Color.Empty, -1, "F3", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 3, False, System.Drawing.Color.Empty, -1, "F4", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 4, True, System.Drawing.Color.Empty, -1, "F5 登録", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 5, False, System.Drawing.Color.Empty, -1, "F6 削除", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 6, False, System.Drawing.Color.Empty, -1, "F7", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 7, True, System.Drawing.Color.Empty, -1, "F8 キャンセル", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 8, False, System.Drawing.Color.Empty, -1, "F9", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 9, True, System.Drawing.Color.Empty, -1, "F10 終了", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 10, True, System.Drawing.Color.Empty, -1, "F11", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 11, True, System.Drawing.Color.Empty, -1, "F12", ""), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 12, True, System.Drawing.Color.Empty, -1, "Home", "Home"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 13, True, System.Drawing.Color.Empty, -1, "End", "End"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 14, True, System.Drawing.Color.Empty, -1, "Page Up", "Page Up"), New GrapeCity.Win.Bars.KeyItem(System.Drawing.Color.Empty, 15, True, System.Drawing.Color.Empty, -1, "Page Down", "Page Down")}))
        Me.ifkMain.StyleSets.Add("XPThemeStyleSet1", New GrapeCity.Win.Bars.XPThemeStyleSet(GrapeCity.Win.Bars.AlignHorizontal.NotSet, GrapeCity.Win.Bars.AlignVertical.NotSet, System.Drawing.SystemColors.Control, New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte)), System.Drawing.SystemColors.ControlText, GrapeCity.Win.Bars.ImagePosition.Left, 2, New GrapeCity.Win.Common.Margins(1, 1, 1, 1), GrapeCity.Win.Common.TextEffect.Flat, False, New GrapeCity.Win.Common.Bevel(System.Drawing.SystemColors.Control, 0, 25, -25), System.Windows.Forms.BorderStyle.Fixed3D))
        Me.ifkMain.ActiveKeySet = "Default"
        Me.ifkMain.ActiveStyleSet = "XPThemeStyleSet1"
        Me.ifkMain.ColumnGroups = "4|4|2"
        Me.ifkMain.Location = New System.Drawing.Point(0, 587)
        Me.ifkMain.Name = "ifkMain"
        Me.ifkMain.Size = New System.Drawing.Size(924, 32)
        Me.ifkMain.TabIndex = 17
        '
        'icntHead
        '
        Me.icntHead.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.icntHead.Controls.Add(Me.iedtPCNO)
        Me.icntHead.Controls.Add(Me.iedtWRTDT)
        Me.icntHead.Controls.Add(Me.iedtStatus)
        Me.icntHead.Controls.Add(Me.iedtKmkCode)
        Me.icntHead.Font = New System.Drawing.Font("ＭＳ ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.icntHead.Location = New System.Drawing.Point(8, 8)
        Me.icntHead.Name = "icntHead"
        Me.icntHead.Size = New System.Drawing.Size(916, 32)
        Me.icntHead.TabIndex = 18
        '
        'iedtPCNO
        '
        Me.iedtPCNO.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.iedtPCNO.BackColor = System.Drawing.Color.Azure
        Me.iedtPCNO.DisabledBackColor = System.Drawing.Color.Azure
        Me.iedtPCNO.DisabledForeColor = System.Drawing.Color.Gray
        Me.iedtPCNO.ForeColor = System.Drawing.Color.Gray
        Me.iedtPCNO.HighlightText = True
        Me.iedtPCNO.Location = New System.Drawing.Point(768, 4)
        Me.iedtPCNO.Name = "iedtPCNO"
        Me.iedtPCNO.ReadOnly = True
        Me.iedtPCNO.Size = New System.Drawing.Size(140, 20)
        Me.iedtPCNO.TabIndex = 5
        Me.iedtPCNO.TabStop = False
        Me.iedtPCNO.Text = "ＷＷＷＷＷＷＷＷＷＷ"
        Me.iedtPCNO.TextVAlign = GrapeCity.Win.Input.Interop.AlignVertical.Middle
        '
        'iedtWRTDT
        '
        Me.iedtWRTDT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.iedtWRTDT.BackColor = System.Drawing.Color.Azure
        Me.iedtWRTDT.DisabledBackColor = System.Drawing.Color.Azure
        Me.iedtWRTDT.DisabledForeColor = System.Drawing.Color.Gray
        Me.iedtWRTDT.ForeColor = System.Drawing.Color.Gray
        Me.iedtWRTDT.HighlightText = True
        Me.iedtWRTDT.Location = New System.Drawing.Point(628, 4)
        Me.iedtWRTDT.Name = "iedtWRTDT"
        Me.iedtWRTDT.ReadOnly = True
        Me.iedtWRTDT.Size = New System.Drawing.Size(140, 20)
        Me.iedtWRTDT.TabIndex = 4
        Me.iedtWRTDT.TabStop = False
        Me.iedtWRTDT.Text = "2009/12/31 23:59:59"
        Me.iedtWRTDT.TextHAlign = GrapeCity.Win.Input.Interop.AlignHorizontal.Center
        Me.iedtWRTDT.TextVAlign = GrapeCity.Win.Input.Interop.AlignVertical.Middle
        '
        'iedtStatus
        '
        Me.iedtStatus.BackColor = System.Drawing.Color.Azure
        Me.iedtStatus.DisabledBackColor = System.Drawing.Color.Azure
        Me.iedtStatus.DisabledForeColor = System.Drawing.Color.Gray
        Me.iedtStatus.ForeColor = System.Drawing.Color.Gray
        Me.iedtStatus.HighlightText = True
        Me.iedtStatus.Location = New System.Drawing.Point(580, 4)
        Me.iedtStatus.Name = "iedtStatus"
        Me.iedtStatus.ReadOnly = True
        Me.iedtStatus.Size = New System.Drawing.Size(48, 20)
        Me.iedtStatus.TabIndex = 1
        Me.iedtStatus.TabStop = False
        Me.iedtStatus.TextHAlign = GrapeCity.Win.Input.Interop.AlignHorizontal.Center
        '
        'iedtKmkCode
        '
        Me.iedtKmkCode.AllowSpace = GrapeCity.Win.Input.Interop.AllowSpace.None
        Me.icntHead.SetCaptionFormat(Me.iedtKmkCode, New GrapeCity.Win.Containers.CaptionFormat(100, 0, System.Drawing.Color.Transparent, System.Drawing.SystemColors.ControlText, System.Drawing.Color.Empty, New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte)), GrapeCity.Win.Common.TextHAlign.NotSet, GrapeCity.Win.Common.TextVAlign.NotSet, GrapeCity.Win.Common.TextEffect.Flat, GrapeCity.Win.Containers.CaptionOrientation.Left, GrapeCity.Win.Common.TextWrapMode.WordWrap))
        Me.icntHead.SetCaptionText(Me.iedtKmkCode, "科目コード")
        Me.iedtKmkCode.Format = "9"
        Me.iedtKmkCode.HighlightText = True
        Me.iedtKmkCode.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.iedtKmkCode.LengthAsByte = True
        Me.iedtKmkCode.Location = New System.Drawing.Point(112, 4)
        Me.iedtKmkCode.MaxLength = 4
        Me.iedtKmkCode.Name = "iedtKmkCode"
        Me.iedtKmkCode.Size = New System.Drawing.Size(60, 20)
        Me.iedtKmkCode.TabIndex = 0
        Me.iedtKmkCode.Text = "9999"
        Me.iedtKmkCode.TextHAlign = GrapeCity.Win.Input.Interop.AlignHorizontal.Right
        '
        'icntMain
        '
        Me.icntMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.icntMain.Controls.Add(Me.chkJigyoNoRenkeiFlg)
        Me.icntMain.Controls.Add(Me.iedtKmkName)
        Me.icntMain.Location = New System.Drawing.Point(8, 48)
        Me.icntMain.Name = "icntMain"
        Me.icntMain.Size = New System.Drawing.Size(916, 536)
        Me.icntMain.TabIndex = 19
        '
        'chkJigyoNoRenkeiFlg
        '
        Me.icntMain.SetCaptionText(Me.chkJigyoNoRenkeiFlg, "事業者登録番号")
        Me.chkJigyoNoRenkeiFlg.Location = New System.Drawing.Point(112, 44)
        Me.chkJigyoNoRenkeiFlg.Name = "chkJigyoNoRenkeiFlg"
        Me.chkJigyoNoRenkeiFlg.Size = New System.Drawing.Size(96, 16)
        Me.chkJigyoNoRenkeiFlg.TabIndex = 5
        Me.chkJigyoNoRenkeiFlg.Text = "連携する"
        '
        'iedtKmkName
        '
        Me.icntMain.SetCaptionText(Me.iedtKmkName, "科目名")
        Me.iedtKmkName.HighlightText = True
        Me.iedtKmkName.ImeMode = System.Windows.Forms.ImeMode.Hiragana
        Me.iedtKmkName.LengthAsByte = True
        Me.iedtKmkName.Location = New System.Drawing.Point(112, 8)
        Me.iedtKmkName.MaxLength = 20
        Me.iedtKmkName.Name = "iedtKmkName"
        Me.iedtKmkName.Size = New System.Drawing.Size(188, 20)
        Me.iedtKmkName.TabIndex = 4
        Me.iedtKmkName.Text = "１２３４５６７８９０"
        '
        'frmNKMTIN91
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 12)
        Me.ClientSize = New System.Drawing.Size(924, 641)
        Me.Controls.Add(Me.icntMain)
        Me.Controls.Add(Me.icntHead)
        Me.Controls.Add(Me.ifkMain)
        Me.Font = New System.Drawing.Font("ＭＳ ゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(940, 680)
        Me.MinimumSize = New System.Drawing.Size(940, 680)
        Me.Name = "frmNKMTIN91"
        Me.Text = "科目登録"
        Me.Controls.SetChildIndex(Me.BaseStatusBar, 0)
        Me.Controls.SetChildIndex(Me.BaseProgressBar, 0)
        Me.Controls.SetChildIndex(Me.ifkMain, 0)
        Me.Controls.SetChildIndex(Me.icntHead, 0)
        Me.Controls.SetChildIndex(Me.icntMain, 0)
        CType(Me.BaseStatusBarPanelMessage1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BaseStatusBarPanelMessage2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BaseStatusBarPanelProgress, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BaseStatusBarPanelDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BaseStatusBarPanelTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BaseProgressBar.ResumeLayout(False)
        Me.icntHead.ResumeLayout(False)
        CType(Me.iedtPCNO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iedtWRTDT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iedtStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.iedtKmkCode, System.ComponentModel.ISupportInitialize).EndInit()
        Me.icntMain.ResumeLayout(False)
        CType(Me.iedtKmkName, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "このクラスに実装したコード"

#Region "enum"

    ''' <summary>画面の入力モードを表わす列挙体です</summary>
    Private Enum EInputMode
		''' <summary>ヘッダ部入力モード</summary>
		Head
		''' <summary>明細部入力モード</summary>
		Detail
	End Enum

	''' <summary>画面の登録モードを表わす列挙体です</summary>
	Private Enum ERegistMode
		''' <summary>新規登録モード</summary>
		Regist
		''' <summary>修正モード</summary>
		Update
		''' <summary>指定なし</summary>
		None
	End Enum

    '2023/12/20 Add (CSS)kajiya 事業者登録番号連携フラグ追加対応 Start
    ''' <summary>事業者登録番号連携フラグを表わす列挙体です</summary>
    Public Enum EJigyoNoRenkeiFlag
        ''' <summary>連携しない</summary>
        RenkeiOff = 0
        ''' <summary>連携する</summary>
        RenkeiOn = 1
    End Enum
    '2023/12/20 Add (CSS)kajiya 事業者登録番号連携フラグ追加対応 End

#End Region ' enum

#Region "const"

    Private Const	TBL_MAIN						As String				= "科目マスタ"

    ' フィールド名
    Private Const FLD_ZMJCD As String = "ZMJCD"               ' 科目マスタ - 科目コード

    '2024/01/05 Add (CSS)kajiya 支払手数料（512）は、連携フラグOFF固定とする対応 Start
    Private Const CODE_SHIHARAITESURYO As Integer = 512
    '2024/01/05 Add (CSS)kajiya 支払手数料（512）は、連携フラグOFF固定とする対応 End

    Private Const SQL_MAIN As String =
            " SELECT * FROM ""科目マスタ"" WHERE {0} "

#End Region ' const

#Region "field"

    Private m_odpex As New ODPEx
    Private			m_ds							As New DataSet

	Private			m_iUserId						As Integer = 0
	Private			m_eRegistMode					As ERegistMode = ERegistMode.None
	Private			m_strSqlMain					As String = Nothing
	Private			m_bProcessCmdKey				As Boolean = False					' ProcessCmdKey 実行中フラグ(同じ処理を何回も実行しないようにする)

#End Region ' field

#Region "property"

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' ユーザー ID の設定・取得
	''' </summary>
	''' <value>ユーザー ID</value>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Property UserId As Integer
		Get
			Return m_iUserId
		End Get
		Set
			m_iUserId = Value
		End Set
	End Property

#End Region ' property

#Region "main"

	<STAThread()> _
	Protected Shared Sub Main(ByVal Args() As String)
		#if DEBUG
			FormSupport.AddExceptionEventHandlerWithContinue()
		#else
			FormSupport.AddExceptionEventHandler()
#End If

        Dim frm As New frmNKMTIN91()
		
		If (0 < Args.Length) Then
			frm.UserId = ConvertEx.ToInt(Args(0))
		End If
		
		Application.Run(frm)
	End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' フォームロード処理
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[furuya]	2009/2/6	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------	
    Private Sub frmNKMTIN91_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

		' DB 接続文字列取得
		m_odpex.ConnectionString = NKIni.GetConnectionString()

		' ユーザー名の表示
		If (0 < UserId) Then
			BaseStatusBarPanelMessage2.Text = NKData.GetUserName(m_odpex, m_iUserId)
		End If

		' コントロール初期化
		InitializeControls()

	End Sub

#End Region ' main

#Region "event"

#Region "event - action"

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' ファンクションキー押下処理
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[furuya]		2009/2/6	Created
    '''		[izumitani]		2009/07/15	Added	Ctrl+Alt+F6 動作不良対応
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub ifkMain_FunctionKeyPress(ByVal sender As Object, ByVal e As GrapeCity.Win.Bars.FunctionKeyPressEventArgs) Handles ifkMain.FunctionKeyPress
		Dim ctrlActive As Control = ActiveControl

        '2018/12/26 EDIT(ST)
        'F5以外は不要
        'ActiveControl = ifkMain
        'ActiveControl = ctrlActive
        '2018/12/27 DEL(ST)
        'そもそも必要ない気がする
        'If (ButtonKeys.F5 = e.Key) Then
        '    ActiveControl = ifkMain
        '    ActiveControl = ctrlActive
        'End If
        '2018/12/27 DEL(END)
        '2018/12/26 EDIT(END)

        Select Case e.Key
			Case ButtonKeys.F1
				' F1 参照
				ActionReference()

			Case ButtonKeys.F5
				' F5 登録
				ActionUpdate()

			' MEMO:(2009/06/26)削除は Ctrl+Alt+F6 で実行するように変更
			'Case ButtonKeys.F6
			'	' F6 削除
			'	ActionDelete()

			Case ButtonKeys.F8
				' F8 キャンセル
				If (DialogResult.Yes <> MessageBoxEx.ShowConfirm(NKConst.MSG_CONF_CANCEL)) Then
                    Exit Select
                End If

				' 各テキストを初期化する
				SetInitialValues()
				SetInputMode(EInputMode.Head)

' [SF-ST: 2009/07/15] Ctrl+Alt+F6 動作不良対応
				m_eRegistMode = ERegistMode.None
' [SF-ED: 2009/07/15]

			Case ButtonKeys.F10
				' F10 終了	
				Close()

            Case Else
				' Do Nothing
		End Select

		e.Handled = True
	End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 科目コードテキストボックスキー押下処理（エンターキーのみ有効）
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[furuya]	2009/2/6	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub iedtKmkCode_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles iedtKmkCode.KeyDown
		Dim cf As New CheckForm

		' Shift、Ctrl、Altキーが押されている場合は何も行わない
		If (e.Shift OrElse e.Control OrElse e.Alt) Then
			Exit Sub
		End If

		If (Keys.Enter = e.KeyCode) Then
			' 0が入力された場合クリア
			If ConvertEx.ToInt(iedtKmkCode.Text) = 0 Then
				iedtKmkCode.Text = String.Empty
			End If
			
			' 科目コード必須チェック
			If(CheckValue.IsEmpty(iedtKmkCode.Text)) Then
				cf.AddError(iedtKmkCode, String.Format(NKConst.MSG_WARN_INPUT_CODE, "科目コード"))
			End If

			If (cf.IsError) Then
				cf.ShowError()
			Else
				' コードが入力されている場合
				ActionGetData()
			End If
			
			e.Handled = True
		End If

	End Sub

	Private Sub Form_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		' 既に実行中の場合は処理しない
		If (m_bProcessCmdKey) Then
			Exit Sub
		End If
		
		' 処理開始
		m_bProcessCmdKey = True

		' MEMO:(2009/06/26)削除は Ctrl+Alt+F6 で実行するように変更
		' F6 削除
		If (Keys.F6 = e.KeyCode) Then
			' Ctrl + Alt キーを押下している場合のみ有効
			If (Not e.Shift AndAlso e.Control AndAlso e.Alt) Then
				If (ERegistMode.Update = m_eRegistMode) Then
					ActionDelete()
				End If
			End If
			e.Handled = True
		End If
		
		' 処理完了
		m_bProcessCmdKey = False
	End Sub

#End Region ' event action

#Region "event - control"

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' フォーカスが変わったさいのイベント
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[furuya]	2009/2/6	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Protected Overrides Sub UpdateDefaultButton()
		MyBase.UpdateDefaultButton()

		' F1 キーの有効／無効変更
		SetEnabledFunctionKeyF1()
	End Sub	

	Private Sub iedtKmkCode_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles iedtKmkCode.Leave

		iedtKmkCode.Text = ConvertEx.ToNumString(iedtKmkCode.Text, iedtKmkCode.MaxLength)

	End Sub

#End Region ' event control

#End Region ' event

#Region "method"

#Region "method - init"

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' コントロール初期化処理
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]		2009/2/6	Created
	'''		[izumitani]		2009/07/15	Added	Ctrl+Alt+F6 動作不良対応
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub InitializeControls()
		' コントロールの Tag を設定
		SetTags()

		' 初期値の設定
		SetInitialValues()

		' 入力可否とフォーカスの設定
		SetInputMode(EInputMode.Head)

' [SF-ST: 2009/07/15] Ctrl+Alt+F6 動作不良対応
		m_eRegistMode = ERegistMode.None
' [SF-ED: 2009/07/15]
	End Sub

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' Tag 設定(ここで設定した Tag はフォーカス時、ステータスバーに表示されます)
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub SetTags()
		iedtKmkCode.Tag = "科目コード"		& MessageEx.INFO_SUFFIX_INPUT
		iedtKmkName.Tag = "科目名"			& MessageEx.INFO_SUFFIX_INPUT
        '2023/12/20 Add (CSS)kajiya 事業者登録番号連携フラグ追加対応 Start
        '事業者登録番号連携フラグ
        chkJigyoNoRenkeiFlg.Tag = "事業者登録番号連携フラグ" & MessageEx.INFO_SUFFIX_INPUT
        '2023/12/20 Add (CSS)kajiya 事業者登録番号連携フラグ追加対応 End
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' 初期値の設定
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[furuya]	2009/2/6	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub SetInitialValues()
		' 初期化
		InputManEx.ClearControlCollection(Me)
	End Sub	

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' ヘッダー、明細部の入力状態設定
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub SetInputMode(ByVal eMode As EInputMode)
		Select Case eMode
			Case EInputMode.Head
				' ヘッダー部のEnableを有効にする
				icntHead.Enabled = True
				' フォーカスを科目コードに設定する
				ActiveControl = iedtKmkCode
				' 明細部のEnableを無効にする
				icntMain.Enabled = False

				' F5 F6キーのEnableを無効にする
				ifkMain.KeySets(0)(EFunction.F05).Enabled = False
				ifkMain.KeySets(0)(EFunction.F06).Enabled = False

			Case EInputMode.Detail
				' 明細部のEnableを有効にする
				icntMain.Enabled = True
				' フォーカスを科目名に設定する
				ActiveControl = iedtKmkName
				' ヘッダー部のEnableを無効にする
				icntHead.Enabled = False

				' F5キーのEnableを有効にする
				ifkMain.KeySets(0)(EFunction.F05).Enabled = True
				' MEMO:(2009/06/26)削除は Ctrl+Alt+F6 で実行するように変更
				'' 登録モードが「修正」の場合はF6キーを有効にする
				'If (ERegistMode.Update = m_eRegistMode) Then
				'	ifkMain.KeySets(0)(EFunction.F06).Enabled = True
				'End If

			Case Else
				' Do Nothing
		End Select
	End Sub

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' F1 キーの有効／無効の設定
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub SetEnabledFunctionKeyF1()
		Select ActiveControl.Name
			Case iedtKmkCode.Name							
				ifkMain.KeySets(0)(EFunction.F01).Enabled = True
			
			Case Else
				ifkMain.KeySets(0)(EFunction.F01).Enabled = False
		End Select
	End Sub

#End Region ' method - init

#Region "method - action"

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' 科目コード Enter 押下
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub ActionGetData()
		Try
			' ファンクションキーを押下不可にする
			ifkMain.Enabled = False
			' マウスカーソルをウェイトカーソルにする
			SetStatusWait()
			' ステータスバーを「処理中」にする
			SetStatusBar(MessageEx.COMM_PROCESSING)

			' 入力されたコードでデータベースを検索する
			If (Not GetKmkData()) Then
				' データが存在しない場合

				' 登録ステータスに "新規" を設定する
				iedtStatus.Text = NKConst.STATUS_NEW

				' 各項目に初期値を設定する
				SetKmkDataNew()

				' 登録モードを「新規」にする
				m_eRegistMode = ERegistMode.Regist

			Else
				' データが存在した場合

				' 登録ステータスに "修正" を設定する
				iedtStatus.Text = NKConst.STATUS_MOD

				' 各項目にデータベースから取得した値を設定する
				SetKmkData()

				' 登録モードを「修正」にする
				m_eRegistMode = ERegistMode.Update
			End If
			
		Finally
			ResetStatusBar()
			ifkMain.Enabled = True
		End Try
		
		' フォーカス、入力可否の設定
		SetInputMode(EInputMode.Detail)
	End Sub

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' 科目マスタの取得
	''' </summary>
	''' <returns>True:データあり、False:データなし</returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Function GetKmkData() As Boolean
		Dim	strSql		As	String				=	Nothing
		Dim	sbwhere		As	StringBuilder		=	New StringBuilder()
		
		' WHERE句の作成
		sbwhere.Append(DACommon.GetSQLWhereString(FLD_ZMJCD, iedtKmkCode.Text, ECompare.Equal))

		strSql			= String.Format(SQL_MAIN, _
										DACommon.ReplaceFirstOperatorToNull(sbWhere.ToString()))
		m_strSqlMain	= strSql

		If (1 = m_odpex.Fill(m_ds, TBL_MAIN, strSQL)) Then
			Return True
		Else
			Return False
		End If
	End Function	

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' F1 参照
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub ActionReference()

        Select Case ActiveControl.Name
            Case iedtKmkCode.Name
                ' 科目検索
                Dim frm As KamokuSearch = Nothing

                Try
                    frm = New KamokuSearch()
                    frm.KmkCode = iedtKmkCode.Text
                    If (DialogResult.OK = frm.ShowDialog(Me)) Then
                        iedtKmkCode.Text = ConvertEx.ToNumString(frm.SelectedKamokuCode, iedtKmkCode.MaxLength)
                        SendKeys.Send("{Enter}")
                    End If

                Finally
                    If (Not Nothing Is frm) Then
                        frm.Dispose()
                        frm = Nothing
                    End If
                End Try

            Case Else
                ' Do Nothing
        End Select
    End Sub
	
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' F5 登録
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]		2009/2/6	Created
	'''		[izumitani]		2009/07/15	Added	Ctrl+Alt+F6 動作不良対応
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub ActionUpdate()
		Try
			' ファンクションキーを押下不可にする
			ifkMain.Enabled = False
			' マウスカーソルをウェイトカーソルにする
			SetStatusWait()
			' ステータスバーを「処理中」にする
			SetStatusBar(MessageEx.COMM_PROCESSING)

			' 入力チェックを行う
			If (Not CheckInputForUpdate()) Then
				' 入力チェックでエラーがあった場合、以降の処理は行わない
				Exit Sub
			End If

			' ステータスバーを「登録中」にする
			SetStatusBar(MessageEx.COMM_DATA_REGISTERING)

			' 「登録確認」のメッセージを表示する
			If (DialogResult.Yes <> MessageBoxEx.ShowConfirm(TBL_MAIN & MessageEx.CONF_ENTRY)) Then
				' 「いいえ」が選択された場合、以降の処理は行わない
				Exit Sub
			End If

			' 画面の内容をデータセットへ登録する
			UpdateDataSet()

			' データベースへ反映
			m_odpex.ResetUpdateArray()
			m_odpex.AddUpdateArray(m_ds, TBL_MAIN, m_strSqlMain)
			If (Not m_odpex.CommitUpdateArray()) Then
				' データベース登録エラーの場合、以降の処理は行わない
				Exit Sub
			End If

			' 「登録完了」のメッセージを表示する
			MessageBoxEx.ShowInformation(TBL_MAIN & MessageEx.COMM_COMPLETE_ENTRY)

			' フォーカス、入力可否の設定
			SetInputMode(EInputMode.Head)

' [SF-ST: 2009/07/15] Ctrl+Alt+F6 動作不良対応
			m_eRegistMode = ERegistMode.None
' [SF-ED: 2009/07/15]

		Finally
			ResetStatusBar()
			ifkMain.Enabled = True
		End Try
	End Sub	
	
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' F5 登録：入力チェック
	''' </summary>
	''' <returns>True:正常、False:エラー</returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Function CheckInputForUpdate() As Boolean
		Dim cf As New CheckForm

		Return Not cf.ShowError()
	End Function
	
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' データセット更新
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------    
	Private Sub UpdateDataSet()
		Dim dr			As DataRow		= Nothing
		Dim dteUpdate	As Date			= Nothing

		' 更新日時の取得
		dteUpdate = Date.Now

		If (ERegistMode.Regist = m_eRegistMode) Then
			dr = m_ds.Tables(TBL_MAIN).NewRow()

			dr("ZMJCD")		= ConvertEx.ToInt(iedtKmkCode.Text)

			m_ds.Tables(TBL_MAIN).Rows.Add(dr)
		Else
			dr = m_ds.Tables(TBL_MAIN).Rows(0)
		End If

		dr("ZMJNM")			= ConvertEx.NullToDBNull(iedtKmkName.Text)

		dr("WRTDT")			= dteUpdate
		dr("PCNO")			= NKConst.PCNO

        '2023/12/20 Add (CSS)kajiya 事業者登録番号連携フラグ追加対応 Start
        '事業者登録番号連携フラグ
        dr("IVRNOFLG") = CInt(IIf(chkJigyoNoRenkeiFlg.Checked, EJigyoNoRenkeiFlag.RenkeiOn, EJigyoNoRenkeiFlag.RenkeiOff))
        '2023/12/20 Add (CSS)kajiya 事業者登録番号連携フラグ追加対応 End

        ' NUMBER型のNULL項目に0をセットする
        NKLibrary.ReplaceDBNullToZero(m_ds.Tables(TBL_MAIN), dr)

	End Sub	

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' F6 削除
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]		2009/2/6	Created
	'''		[izumitani]		2009/07/15	Added	Ctrl+Alt+F6 動作不良対応
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub ActionDelete()
		Try
			' ファンクションキーを押下不可にする
			ifkMain.Enabled = False
			' マウスカーソルをウェイトカーソルにする
			SetStatusWait()
			' ステータスバーを「処理中」にする
			SetStatusBar(MessageEx.COMM_PROCESSING)

			' 「削除確認」のメッセージを表示する
			If (DialogResult.Yes <> MessageBoxEx.ShowConfirm(TBL_MAIN & MessageEx.CONF_DELETE)) Then
				' 「いいえ」が選択された場合、以降の処理は行わない
				Exit Sub
			End If

			'ステータスバーを「削除中」にする
			SetStatusBar(MessageEx.COMM_DATA_DELETING)

			'取得した科目マスタのデータをデータベースから削除する
			m_ds.Tables(TBL_MAIN).Rows(0).Delete()

			' データベースへ反映
			m_odpex.ResetUpdateArray()
			m_odpex.AddUpdateArray(m_ds, TBL_MAIN, m_strSqlMain)
			If (Not m_odpex.CommitUpdateArray()) Then
				' 削除エラーの場合、以降の処理は行わない
				Exit Sub
			End If

			' 「削除完了」のメッセージを表示する
			MessageBoxEx.ShowInformation(TBL_MAIN & MessageEx.COMM_COMPLETE_DELETE)

			' フォーカス、入力可否の設定
			SetInitialValues()
			SetInputMode(EInputMode.Head)

' [SF-ST: 2009/07/15] Ctrl+Alt+F6 動作不良対応
			m_eRegistMode = ERegistMode.None
' [SF-ED: 2009/07/15]

		Finally
			ResetStatusBar()
			ifkMain.Enabled = True
		End Try
	End Sub    

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' 取得した科目マスタのデータを画面に設定
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub SetKmkData()
		Dim	dr		As	DataRow	=	Nothing

		dr = m_ds.Tables(TBL_MAIN).Rows(0)
		
		' 登録日付を設定する
		iedtWRTDT.Text			= DateTimeEx.ToDateTimeString(dr("WRTDT"))
		' 更新者IDを設定する
		iedtPCNO.Text			= ConvertEx.ToString(dr("PCNO"))

        '2023/12/20 Add (CSS)kajiya 事業者登録番号連携フラグ追加対応 Start
        '事業者登録番号連携フラグ
        chkJigyoNoRenkeiFlg.Checked = CBool(IIf(ConvertEx.ToInt(dr("IVRNOFLG")) = EJigyoNoRenkeiFlag.RenkeiOn, True, False))
        '2023/12/20 Add (CSS)kajiya 事業者登録番号連携フラグ追加対応 End

        '2024/04/23 Del CSS)shoji 販売管理システムからのデータ連携で512(支払手数料)はシステム経費のみに利用することになったため、連携可能とする Start
        ''2024/01/05 Add (CSS)kajiya 支払手数料（512）は、連携フラグOFF固定とする対応 Start
        ''--科目コードが支払手数料（512）時は、事業者登録番号連携フラグを入力不可とする、
        'If ConvertEx.ToInt(dr("ZMJCD")) = CODE_SHIHARAITESURYO Then
        '    chkJigyoNoRenkeiFlg.Enabled = False
        '    lblJigyoNoRenkeiFlg.Text = "科目コードが支払手数料（512）の場合、事業者登録番号連携フラグはチェックできません。"
        '    lblJigyoNoRenkeiFlg.Visible = True
        'Else
        '    chkJigyoNoRenkeiFlg.Enabled = True
        '    lblJigyoNoRenkeiFlg.Text = String.Empty
        '    lblJigyoNoRenkeiFlg.Visible = False
        'End If
        ''2024/01/05 Add (CSS)kajiya 支払手数料（512）は、連携フラグOFF固定とする対応 End
        '2024/04/23 Del CSS)shoji 販売管理システムからのデータ連携で512(支払手数料)はシステム経費のみに利用することになったため、連携可能とする End

        iedtKmkName.Text = ConvertEx.ToString(dr("ZMJNM"))

    End Sub
	
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' 初期値を画面に設定
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[furuya]	2009/2/6	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Private Sub SetKmkDataNew()
		' 登録日付
		iedtWRTDT.Text	= string.Empty
        ' 更新者ID
        iedtPCNO.Text = String.Empty

        InputManEx.ClearControlCollection(icntMain)

    End Sub

#End Region ' method - action

#End Region ' method

#End Region ' このクラスに実装したコード

End Class
