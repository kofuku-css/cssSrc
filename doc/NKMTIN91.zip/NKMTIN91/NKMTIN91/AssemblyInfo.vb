﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' アセンブリに関する一般情報は以下の
' 属性セットを通して制御されます。アセンブリに関連付けられている情報を変更するには、
' これらの属性値を変更してください。 

' アセンブリ属性の値を確認します。

<Assembly: AssemblyTitle("NKMTIN91.exe")> 
<Assembly: AssemblyDescription("科目登録")> 
<Assembly: AssemblyCompany("Comsystem")> 
<Assembly: AssemblyProduct("販売管理システム")> 
<Assembly: AssemblyCopyright("Copyright(C) 2009 ComSystem Co.,Ltd. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(False)>

'以下の GUID は、このプロジェクトが COM に公開された場合、タイプ ライブラリの ID になります。
<Assembly: Guid("A9FC919E-F87C-4259-9D1F-3FD014665D64")> 

' アセンブリのバージョン情報は、以下の 4 つの属性で構成されます :
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' 下にあるように、'*' を使って、すべての値を指定するか、
' ビルドおよびリビジョン番号を既定値にすることができます。

<Assembly: AssemblyVersion("1.0.*")> 
